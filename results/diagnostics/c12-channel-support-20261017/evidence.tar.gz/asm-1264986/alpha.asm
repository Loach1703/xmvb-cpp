000000000044048d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver] [clone .cold]>:
  44048d:	f6 c4 04             	test   $0x4,%ah
  440490:	74 0a                	je     44049c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver] [clone .cold]+0xf>
  440492:	b8 90 db 84 00       	mov    $0x84db90,%eax
  440497:	e9 71 d7 41 00       	jmp    85dc0d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver]+0x1d>
  44049c:	b8 e0 d2 84 00       	mov    $0x84d2e0,%eax
  4404a1:	e9 67 d7 41 00       	jmp    85dc0d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver]+0x1d>

000000000084d2e0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]>:
  84d2e0:	55                   	push   %rbp
  84d2e1:	48 89 f8             	mov    %rdi,%rax
  84d2e4:	49 89 f3             	mov    %rsi,%r11
  84d2e7:	48 89 e5             	mov    %rsp,%rbp
  84d2ea:	48 c7 45 f8 00 00 00 	movq   $0x0,-0x8(%rbp)
  84d2f1:	00 
  84d2f2:	48 8b 7d 10          	mov    0x10(%rbp),%rdi
  84d2f6:	85 f6                	test   %esi,%esi
  84d2f8:	7e 5a                	jle    84d354 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x74>
  84d2fa:	48 89 d6             	mov    %rdx,%rsi
  84d2fd:	45 84 c0             	test   %r8b,%r8b
  84d300:	75 5e                	jne    84d360 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x80>
  84d302:	4d 63 db             	movslq %r11d,%r11
  84d305:	49 89 ca             	mov    %rcx,%r10
  84d308:	49 c1 e3 04          	shl    $0x4,%r11
  84d30c:	41 83 f9 01          	cmp    $0x1,%r9d
  84d310:	0f 85 7e 01 00 00    	jne    84d494 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x1b4>
  84d316:	66 0f ef c9          	pxor   %xmm1,%xmm1
  84d31a:	4d 8d 04 03          	lea    (%r11,%rax,1),%r8
  84d31e:	66 0f 28 d9          	movapd %xmm1,%xmm3
  84d322:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84d328:	48 63 10             	movslq (%rax),%rdx
  84d32b:	49 63 0c 92          	movslq (%r10,%rdx,4),%rcx
  84d32f:	31 d2                	xor    %edx,%edx
  84d331:	85 c9                	test   %ecx,%ecx
  84d333:	48 0f 49 d1          	cmovns %rcx,%rdx
  84d337:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84d33a:	09 d1                	or     %edx,%ecx
  84d33c:	0f 89 9e 00 00 00    	jns    84d3e0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x100>
  84d342:	48 83 c0 10          	add    $0x10,%rax
  84d346:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
  84d34a:	49 39 c0             	cmp    %rax,%r8
  84d34d:	75 d9                	jne    84d328 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x48>
  84d34f:	f2 0f 11 4d f8       	movsd  %xmm1,-0x8(%rbp)
  84d354:	f2 0f 58 45 f8       	addsd  -0x8(%rbp),%xmm0
  84d359:	5d                   	pop    %rbp
  84d35a:	c3                   	ret    
  84d35b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  84d360:	41 83 f9 01          	cmp    $0x1,%r9d
  84d364:	0f 85 ab 00 00 00    	jne    84d415 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x135>
  84d36a:	4d 63 db             	movslq %r11d,%r11
  84d36d:	66 0f ef c9          	pxor   %xmm1,%xmm1
  84d371:	49 c1 e3 04          	shl    $0x4,%r11
  84d375:	66 0f 28 d9          	movapd %xmm1,%xmm3
  84d379:	4d 8d 04 03          	lea    (%r11,%rax,1),%r8
  84d37d:	0f 1f 00             	nopl   (%rax)
  84d380:	48 63 08             	movslq (%rax),%rcx
  84d383:	31 d2                	xor    %edx,%edx
  84d385:	85 c9                	test   %ecx,%ecx
  84d387:	48 0f 49 d1          	cmovns %rcx,%rdx
  84d38b:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84d38e:	09 d1                	or     %edx,%ecx
  84d390:	79 16                	jns    84d3a8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xc8>
  84d392:	48 83 c0 10          	add    $0x10,%rax
  84d396:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
  84d39a:	4c 39 c0             	cmp    %r8,%rax
  84d39d:	75 e1                	jne    84d380 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xa0>
  84d39f:	eb ae                	jmp    84d34f <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x6f>
  84d3a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  84d3a8:	31 c9                	xor    %ecx,%ecx
  84d3aa:	85 d2                	test   %edx,%edx
  84d3ac:	0f 48 d1             	cmovs  %ecx,%edx
  84d3af:	0f b7 48 04          	movzwl 0x4(%rax),%ecx
  84d3b3:	48 83 c0 10          	add    $0x10,%rax
  84d3b7:	01 ca                	add    %ecx,%edx
  84d3b9:	48 63 d2             	movslq %edx,%rdx
  84d3bc:	f2 0f 10 14 d7       	movsd  (%rdi,%rdx,8),%xmm2
  84d3c1:	f2 0f 59 50 f8       	mulsd  -0x8(%rax),%xmm2
  84d3c6:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
  84d3ca:	49 39 c0             	cmp    %rax,%r8
  84d3cd:	75 b1                	jne    84d380 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xa0>
  84d3cf:	f2 0f 11 4d f8       	movsd  %xmm1,-0x8(%rbp)
  84d3d4:	e9 7b ff ff ff       	jmp    84d354 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x74>
  84d3d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  84d3e0:	31 c9                	xor    %ecx,%ecx
  84d3e2:	85 d2                	test   %edx,%edx
  84d3e4:	0f 48 d1             	cmovs  %ecx,%edx
  84d3e7:	0f b7 48 04          	movzwl 0x4(%rax),%ecx
  84d3eb:	48 83 c0 10          	add    $0x10,%rax
  84d3ef:	01 ca                	add    %ecx,%edx
  84d3f1:	48 63 d2             	movslq %edx,%rdx
  84d3f4:	f2 0f 10 14 d7       	movsd  (%rdi,%rdx,8),%xmm2
  84d3f9:	f2 0f 59 50 f8       	mulsd  -0x8(%rax),%xmm2
  84d3fe:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
  84d402:	49 39 c0             	cmp    %rax,%r8
  84d405:	0f 85 1d ff ff ff    	jne    84d328 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x48>
  84d40b:	f2 0f 11 4d f8       	movsd  %xmm1,-0x8(%rbp)
  84d410:	e9 3f ff ff ff       	jmp    84d354 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x74>
  84d415:	4d 63 db             	movslq %r11d,%r11
  84d418:	66 0f ef c9          	pxor   %xmm1,%xmm1
  84d41c:	49 c1 e3 04          	shl    $0x4,%r11
  84d420:	66 0f 28 d9          	movapd %xmm1,%xmm3
  84d424:	49 8d 0c 03          	lea    (%r11,%rax,1),%rcx
  84d428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  84d42f:	00 
  84d430:	4c 63 00             	movslq (%rax),%r8
  84d433:	31 d2                	xor    %edx,%edx
  84d435:	45 85 c0             	test   %r8d,%r8d
  84d438:	49 0f 49 d0          	cmovns %r8,%rdx
  84d43c:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84d43f:	41 09 d0             	or     %edx,%r8d
  84d442:	79 1c                	jns    84d460 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x180>
  84d444:	48 83 c0 10          	add    $0x10,%rax
  84d448:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
  84d44c:	48 39 c8             	cmp    %rcx,%rax
  84d44f:	75 df                	jne    84d430 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x150>
  84d451:	e9 f9 fe ff ff       	jmp    84d34f <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x6f>
  84d456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84d45d:	00 00 00 
  84d460:	45 31 c0             	xor    %r8d,%r8d
  84d463:	85 d2                	test   %edx,%edx
  84d465:	41 0f 48 d0          	cmovs  %r8d,%edx
  84d469:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84d46e:	48 83 c0 10          	add    $0x10,%rax
  84d472:	41 0f af d1          	imul   %r9d,%edx
  84d476:	44 01 c2             	add    %r8d,%edx
  84d479:	48 63 d2             	movslq %edx,%rdx
  84d47c:	f2 0f 10 14 d7       	movsd  (%rdi,%rdx,8),%xmm2
  84d481:	f2 0f 59 50 f8       	mulsd  -0x8(%rax),%xmm2
  84d486:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
  84d48a:	48 39 c1             	cmp    %rax,%rcx
  84d48d:	75 a1                	jne    84d430 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x150>
  84d48f:	e9 bb fe ff ff       	jmp    84d34f <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x6f>
  84d494:	66 0f ef c9          	pxor   %xmm1,%xmm1
  84d498:	49 8d 0c 03          	lea    (%r11,%rax,1),%rcx
  84d49c:	66 0f 28 d9          	movapd %xmm1,%xmm3
  84d4a0:	48 63 10             	movslq (%rax),%rdx
  84d4a3:	4d 63 04 92          	movslq (%r10,%rdx,4),%r8
  84d4a7:	31 d2                	xor    %edx,%edx
  84d4a9:	45 85 c0             	test   %r8d,%r8d
  84d4ac:	49 0f 49 d0          	cmovns %r8,%rdx
  84d4b0:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84d4b3:	41 09 d0             	or     %edx,%r8d
  84d4b6:	79 18                	jns    84d4d0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x1f0>
  84d4b8:	48 83 c0 10          	add    $0x10,%rax
  84d4bc:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
  84d4c0:	48 39 c8             	cmp    %rcx,%rax
  84d4c3:	75 db                	jne    84d4a0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x1c0>
  84d4c5:	e9 85 fe ff ff       	jmp    84d34f <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x6f>
  84d4ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84d4d0:	45 31 c0             	xor    %r8d,%r8d
  84d4d3:	85 d2                	test   %edx,%edx
  84d4d5:	41 0f 48 d0          	cmovs  %r8d,%edx
  84d4d9:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84d4de:	48 83 c0 10          	add    $0x10,%rax
  84d4e2:	41 0f af d1          	imul   %r9d,%edx
  84d4e6:	44 01 c2             	add    %r8d,%edx
  84d4e9:	48 63 d2             	movslq %edx,%rdx
  84d4ec:	f2 0f 10 14 d7       	movsd  (%rdi,%rdx,8),%xmm2
  84d4f1:	f2 0f 59 50 f8       	mulsd  -0x8(%rax),%xmm2
  84d4f6:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
  84d4fa:	48 39 c1             	cmp    %rax,%rcx
  84d4fd:	75 a1                	jne    84d4a0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x1c0>
  84d4ff:	e9 4b fe ff ff       	jmp    84d34f <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x6f>
  84d504:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84d50b:	00 00 00 
  84d50e:	66 90                	xchg   %ax,%ax

000000000084d980 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]>:
  84d980:	55                   	push   %rbp
  84d981:	48 89 e5             	mov    %rsp,%rbp
  84d984:	48 83 e4 c0          	and    $0xffffffffffffffc0,%rsp
  84d988:	48 c7 44 24 c0 00 00 	movq   $0x0,-0x40(%rsp)
  84d98f:	00 00 
  84d991:	4c 8b 55 10          	mov    0x10(%rbp),%r10
  84d995:	85 f6                	test   %esi,%esi
  84d997:	7e 54                	jle    84d9ed <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x6d>
  84d999:	48 89 f8             	mov    %rdi,%rax
  84d99c:	45 84 c0             	test   %r8b,%r8b
  84d99f:	75 57                	jne    84d9f8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x78>
  84d9a1:	48 63 f6             	movslq %esi,%rsi
  84d9a4:	48 c1 e6 04          	shl    $0x4,%rsi
  84d9a8:	41 83 f9 01          	cmp    $0x1,%r9d
  84d9ac:	0f 85 64 01 00 00    	jne    84db16 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x196>
  84d9b2:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84d9b6:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
  84d9ba:	c5 f3 10 d1          	vmovsd %xmm1,%xmm1,%xmm2
  84d9be:	66 90                	xchg   %ax,%ax
  84d9c0:	48 63 30             	movslq (%rax),%rsi
  84d9c3:	48 63 3c b1          	movslq (%rcx,%rsi,4),%rdi
  84d9c7:	31 f6                	xor    %esi,%esi
  84d9c9:	85 ff                	test   %edi,%edi
  84d9cb:	48 0f 49 f7          	cmovns %rdi,%rsi
  84d9cf:	8b 34 b2             	mov    (%rdx,%rsi,4),%esi
  84d9d2:	09 f7                	or     %esi,%edi
  84d9d4:	0f 89 96 00 00 00    	jns    84da70 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xf0>
  84d9da:	48 83 c0 10          	add    $0x10,%rax
  84d9de:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84d9e2:	4c 39 c0             	cmp    %r8,%rax
  84d9e5:	75 d9                	jne    84d9c0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x40>
  84d9e7:	c5 fb 11 4c 24 c0    	vmovsd %xmm1,-0x40(%rsp)
  84d9ed:	c5 fb 58 44 24 c0    	vaddsd -0x40(%rsp),%xmm0,%xmm0
  84d9f3:	c9                   	leave  
  84d9f4:	c3                   	ret    
  84d9f5:	0f 1f 00             	nopl   (%rax)
  84d9f8:	41 83 f9 01          	cmp    $0x1,%r9d
  84d9fc:	0f 85 a2 00 00 00    	jne    84daa4 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x124>
  84da02:	48 63 f6             	movslq %esi,%rsi
  84da05:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84da09:	48 c1 e6 04          	shl    $0x4,%rsi
  84da0d:	c5 f3 10 d1          	vmovsd %xmm1,%xmm1,%xmm2
  84da11:	48 8d 3c 3e          	lea    (%rsi,%rdi,1),%rdi
  84da15:	0f 1f 00             	nopl   (%rax)
  84da18:	48 63 30             	movslq (%rax),%rsi
  84da1b:	31 c9                	xor    %ecx,%ecx
  84da1d:	85 f6                	test   %esi,%esi
  84da1f:	48 0f 49 ce          	cmovns %rsi,%rcx
  84da23:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
  84da26:	09 ce                	or     %ecx,%esi
  84da28:	79 16                	jns    84da40 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xc0>
  84da2a:	48 83 c0 10          	add    $0x10,%rax
  84da2e:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84da32:	48 39 f8             	cmp    %rdi,%rax
  84da35:	75 e1                	jne    84da18 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x98>
  84da37:	eb ae                	jmp    84d9e7 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x67>
  84da39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  84da40:	31 f6                	xor    %esi,%esi
  84da42:	85 c9                	test   %ecx,%ecx
  84da44:	0f 48 ce             	cmovs  %esi,%ecx
  84da47:	0f b7 70 04          	movzwl 0x4(%rax),%esi
  84da4b:	48 83 c0 10          	add    $0x10,%rax
  84da4f:	01 f1                	add    %esi,%ecx
  84da51:	48 63 c9             	movslq %ecx,%rcx
  84da54:	c4 c1 7b 10 24 ca    	vmovsd (%r10,%rcx,8),%xmm4
  84da5a:	c4 e2 d9 b9 48 f8    	vfmadd231sd -0x8(%rax),%xmm4,%xmm1
  84da60:	48 39 f8             	cmp    %rdi,%rax
  84da63:	75 b3                	jne    84da18 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x98>
  84da65:	c5 fb 11 4c 24 c0    	vmovsd %xmm1,-0x40(%rsp)
  84da6b:	eb 80                	jmp    84d9ed <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x6d>
  84da6d:	0f 1f 00             	nopl   (%rax)
  84da70:	31 ff                	xor    %edi,%edi
  84da72:	85 f6                	test   %esi,%esi
  84da74:	0f 48 f7             	cmovs  %edi,%esi
  84da77:	0f b7 78 04          	movzwl 0x4(%rax),%edi
  84da7b:	48 83 c0 10          	add    $0x10,%rax
  84da7f:	01 fe                	add    %edi,%esi
  84da81:	48 63 f6             	movslq %esi,%rsi
  84da84:	c4 c1 7b 10 1c f2    	vmovsd (%r10,%rsi,8),%xmm3
  84da8a:	c4 e2 e1 b9 48 f8    	vfmadd231sd -0x8(%rax),%xmm3,%xmm1
  84da90:	4c 39 c0             	cmp    %r8,%rax
  84da93:	0f 85 27 ff ff ff    	jne    84d9c0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x40>
  84da99:	c5 fb 11 4c 24 c0    	vmovsd %xmm1,-0x40(%rsp)
  84da9f:	e9 49 ff ff ff       	jmp    84d9ed <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x6d>
  84daa4:	48 63 f6             	movslq %esi,%rsi
  84daa7:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84daab:	48 c1 e6 04          	shl    $0x4,%rsi
  84daaf:	c5 f3 10 d1          	vmovsd %xmm1,%xmm1,%xmm2
  84dab3:	48 01 fe             	add    %rdi,%rsi
  84dab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84dabd:	00 00 00 
  84dac0:	48 63 38             	movslq (%rax),%rdi
  84dac3:	31 c9                	xor    %ecx,%ecx
  84dac5:	85 ff                	test   %edi,%edi
  84dac7:	48 0f 49 cf          	cmovns %rdi,%rcx
  84dacb:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
  84dace:	09 cf                	or     %ecx,%edi
  84dad0:	79 16                	jns    84dae8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x168>
  84dad2:	48 83 c0 10          	add    $0x10,%rax
  84dad6:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84dada:	48 39 c6             	cmp    %rax,%rsi
  84dadd:	75 e1                	jne    84dac0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x140>
  84dadf:	e9 03 ff ff ff       	jmp    84d9e7 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x67>
  84dae4:	0f 1f 40 00          	nopl   0x0(%rax)
  84dae8:	31 ff                	xor    %edi,%edi
  84daea:	85 c9                	test   %ecx,%ecx
  84daec:	0f 48 cf             	cmovs  %edi,%ecx
  84daef:	0f b7 78 04          	movzwl 0x4(%rax),%edi
  84daf3:	48 83 c0 10          	add    $0x10,%rax
  84daf7:	41 0f af c9          	imul   %r9d,%ecx
  84dafb:	01 f9                	add    %edi,%ecx
  84dafd:	48 63 c9             	movslq %ecx,%rcx
  84db00:	c4 c1 7b 10 34 ca    	vmovsd (%r10,%rcx,8),%xmm6
  84db06:	c4 e2 c9 b9 48 f8    	vfmadd231sd -0x8(%rax),%xmm6,%xmm1
  84db0c:	48 39 f0             	cmp    %rsi,%rax
  84db0f:	75 af                	jne    84dac0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x140>
  84db11:	e9 d1 fe ff ff       	jmp    84d9e7 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x67>
  84db16:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84db1a:	48 8d 3c 3e          	lea    (%rsi,%rdi,1),%rdi
  84db1e:	c5 f3 10 d1          	vmovsd %xmm1,%xmm1,%xmm2
  84db22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84db28:	48 63 30             	movslq (%rax),%rsi
  84db2b:	4c 63 04 b1          	movslq (%rcx,%rsi,4),%r8
  84db2f:	31 f6                	xor    %esi,%esi
  84db31:	45 85 c0             	test   %r8d,%r8d
  84db34:	49 0f 49 f0          	cmovns %r8,%rsi
  84db38:	8b 34 b2             	mov    (%rdx,%rsi,4),%esi
  84db3b:	41 09 f0             	or     %esi,%r8d
  84db3e:	79 18                	jns    84db58 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x1d8>
  84db40:	48 83 c0 10          	add    $0x10,%rax
  84db44:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84db48:	48 39 f8             	cmp    %rdi,%rax
  84db4b:	75 db                	jne    84db28 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x1a8>
  84db4d:	e9 95 fe ff ff       	jmp    84d9e7 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x67>
  84db52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84db58:	45 31 c0             	xor    %r8d,%r8d
  84db5b:	85 f6                	test   %esi,%esi
  84db5d:	c5 fb 10 68 08       	vmovsd 0x8(%rax),%xmm5
  84db62:	41 0f 48 f0          	cmovs  %r8d,%esi
  84db66:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84db6b:	48 83 c0 10          	add    $0x10,%rax
  84db6f:	41 0f af f1          	imul   %r9d,%esi
  84db73:	44 01 c6             	add    %r8d,%esi
  84db76:	48 63 f6             	movslq %esi,%rsi
  84db79:	c4 c2 d1 b9 0c f2    	vfmadd231sd (%r10,%rsi,8),%xmm5,%xmm1
  84db7f:	48 39 f8             	cmp    %rdi,%rax
  84db82:	75 a4                	jne    84db28 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x1a8>
  84db84:	e9 5e fe ff ff       	jmp    84d9e7 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x67>
  84db89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000084db90 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]>:
  84db90:	55                   	push   %rbp
  84db91:	48 89 f8             	mov    %rdi,%rax
  84db94:	49 89 f3             	mov    %rsi,%r11
  84db97:	48 89 e5             	mov    %rsp,%rbp
  84db9a:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
  84db9e:	48 c7 44 24 e0 00 00 	movq   $0x0,-0x20(%rsp)
  84dba5:	00 00 
  84dba7:	48 8b 7d 10          	mov    0x10(%rbp),%rdi
  84dbab:	85 f6                	test   %esi,%esi
  84dbad:	7e 5e                	jle    84dc0d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x7d>
  84dbaf:	48 89 d6             	mov    %rdx,%rsi
  84dbb2:	45 84 c0             	test   %r8b,%r8b
  84dbb5:	75 61                	jne    84dc18 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x88>
  84dbb7:	4d 63 db             	movslq %r11d,%r11
  84dbba:	49 89 ca             	mov    %rcx,%r10
  84dbbd:	49 c1 e3 04          	shl    $0x4,%r11
  84dbc1:	41 83 f9 01          	cmp    $0x1,%r9d
  84dbc5:	0f 85 79 01 00 00    	jne    84dd44 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x1b4>
  84dbcb:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84dbcf:	4d 8d 04 03          	lea    (%r11,%rax,1),%r8
  84dbd3:	c5 f9 28 d9          	vmovapd %xmm1,%xmm3
  84dbd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  84dbde:	00 00 
  84dbe0:	48 63 10             	movslq (%rax),%rdx
  84dbe3:	49 63 0c 92          	movslq (%r10,%rdx,4),%rcx
  84dbe7:	31 d2                	xor    %edx,%edx
  84dbe9:	85 c9                	test   %ecx,%ecx
  84dbeb:	48 0f 49 d1          	cmovns %rcx,%rdx
  84dbef:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84dbf2:	09 d1                	or     %edx,%ecx
  84dbf4:	0f 89 9e 00 00 00    	jns    84dc98 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x108>
  84dbfa:	48 83 c0 10          	add    $0x10,%rax
  84dbfe:	c5 f3 58 cb          	vaddsd %xmm3,%xmm1,%xmm1
  84dc02:	49 39 c0             	cmp    %rax,%r8
  84dc05:	75 d9                	jne    84dbe0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x50>
  84dc07:	c5 fb 11 4c 24 e0    	vmovsd %xmm1,-0x20(%rsp)
  84dc0d:	c5 fb 58 44 24 e0    	vaddsd -0x20(%rsp),%xmm0,%xmm0
  84dc13:	c9                   	leave  
  84dc14:	c3                   	ret    
  84dc15:	0f 1f 00             	nopl   (%rax)
  84dc18:	41 83 f9 01          	cmp    $0x1,%r9d
  84dc1c:	0f 85 ac 00 00 00    	jne    84dcce <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x13e>
  84dc22:	4d 63 db             	movslq %r11d,%r11
  84dc25:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84dc29:	49 c1 e3 04          	shl    $0x4,%r11
  84dc2d:	c5 f9 28 d9          	vmovapd %xmm1,%xmm3
  84dc31:	4d 8d 04 03          	lea    (%r11,%rax,1),%r8
  84dc35:	0f 1f 00             	nopl   (%rax)
  84dc38:	48 63 08             	movslq (%rax),%rcx
  84dc3b:	31 d2                	xor    %edx,%edx
  84dc3d:	85 c9                	test   %ecx,%ecx
  84dc3f:	48 0f 49 d1          	cmovns %rcx,%rdx
  84dc43:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84dc46:	09 d1                	or     %edx,%ecx
  84dc48:	79 16                	jns    84dc60 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xd0>
  84dc4a:	48 83 c0 10          	add    $0x10,%rax
  84dc4e:	c5 f3 58 cb          	vaddsd %xmm3,%xmm1,%xmm1
  84dc52:	49 39 c0             	cmp    %rax,%r8
  84dc55:	75 e1                	jne    84dc38 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xa8>
  84dc57:	eb ae                	jmp    84dc07 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x77>
  84dc59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  84dc60:	31 c9                	xor    %ecx,%ecx
  84dc62:	85 d2                	test   %edx,%edx
  84dc64:	0f 48 d1             	cmovs  %ecx,%edx
  84dc67:	0f b7 48 04          	movzwl 0x4(%rax),%ecx
  84dc6b:	48 83 c0 10          	add    $0x10,%rax
  84dc6f:	01 ca                	add    %ecx,%edx
  84dc71:	48 63 d2             	movslq %edx,%rdx
  84dc74:	c5 fb 10 14 d7       	vmovsd (%rdi,%rdx,8),%xmm2
  84dc79:	c5 eb 59 50 f8       	vmulsd -0x8(%rax),%xmm2,%xmm2
  84dc7e:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84dc82:	4c 39 c0             	cmp    %r8,%rax
  84dc85:	75 b1                	jne    84dc38 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xa8>
  84dc87:	c5 fb 11 4c 24 e0    	vmovsd %xmm1,-0x20(%rsp)
  84dc8d:	e9 7b ff ff ff       	jmp    84dc0d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x7d>
  84dc92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84dc98:	31 c9                	xor    %ecx,%ecx
  84dc9a:	85 d2                	test   %edx,%edx
  84dc9c:	0f 48 d1             	cmovs  %ecx,%edx
  84dc9f:	0f b7 48 04          	movzwl 0x4(%rax),%ecx
  84dca3:	48 83 c0 10          	add    $0x10,%rax
  84dca7:	01 ca                	add    %ecx,%edx
  84dca9:	48 63 d2             	movslq %edx,%rdx
  84dcac:	c5 fb 10 14 d7       	vmovsd (%rdi,%rdx,8),%xmm2
  84dcb1:	c5 eb 59 50 f8       	vmulsd -0x8(%rax),%xmm2,%xmm2
  84dcb6:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84dcba:	4c 39 c0             	cmp    %r8,%rax
  84dcbd:	0f 85 1d ff ff ff    	jne    84dbe0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x50>
  84dcc3:	c5 fb 11 4c 24 e0    	vmovsd %xmm1,-0x20(%rsp)
  84dcc9:	e9 3f ff ff ff       	jmp    84dc0d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x7d>
  84dcce:	4d 63 db             	movslq %r11d,%r11
  84dcd1:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84dcd5:	49 c1 e3 04          	shl    $0x4,%r11
  84dcd9:	c5 f9 28 d9          	vmovapd %xmm1,%xmm3
  84dcdd:	49 8d 0c 03          	lea    (%r11,%rax,1),%rcx
  84dce1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  84dce8:	4c 63 00             	movslq (%rax),%r8
  84dceb:	31 d2                	xor    %edx,%edx
  84dced:	45 85 c0             	test   %r8d,%r8d
  84dcf0:	49 0f 49 d0          	cmovns %r8,%rdx
  84dcf4:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84dcf7:	41 09 d0             	or     %edx,%r8d
  84dcfa:	79 14                	jns    84dd10 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x180>
  84dcfc:	48 83 c0 10          	add    $0x10,%rax
  84dd00:	c5 f3 58 cb          	vaddsd %xmm3,%xmm1,%xmm1
  84dd04:	48 39 c1             	cmp    %rax,%rcx
  84dd07:	75 df                	jne    84dce8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x158>
  84dd09:	e9 f9 fe ff ff       	jmp    84dc07 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x77>
  84dd0e:	66 90                	xchg   %ax,%ax
  84dd10:	45 31 c0             	xor    %r8d,%r8d
  84dd13:	85 d2                	test   %edx,%edx
  84dd15:	41 0f 48 d0          	cmovs  %r8d,%edx
  84dd19:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84dd1e:	48 83 c0 10          	add    $0x10,%rax
  84dd22:	41 0f af d1          	imul   %r9d,%edx
  84dd26:	44 01 c2             	add    %r8d,%edx
  84dd29:	48 63 d2             	movslq %edx,%rdx
  84dd2c:	c5 fb 10 14 d7       	vmovsd (%rdi,%rdx,8),%xmm2
  84dd31:	c5 eb 59 50 f8       	vmulsd -0x8(%rax),%xmm2,%xmm2
  84dd36:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84dd3a:	48 39 c1             	cmp    %rax,%rcx
  84dd3d:	75 a9                	jne    84dce8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x158>
  84dd3f:	e9 c3 fe ff ff       	jmp    84dc07 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x77>
  84dd44:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84dd48:	49 8d 0c 03          	lea    (%r11,%rax,1),%rcx
  84dd4c:	c5 f9 28 d9          	vmovapd %xmm1,%xmm3
  84dd50:	48 63 10             	movslq (%rax),%rdx
  84dd53:	4d 63 04 92          	movslq (%r10,%rdx,4),%r8
  84dd57:	31 d2                	xor    %edx,%edx
  84dd59:	45 85 c0             	test   %r8d,%r8d
  84dd5c:	49 0f 49 d0          	cmovns %r8,%rdx
  84dd60:	8b 14 96             	mov    (%rsi,%rdx,4),%edx
  84dd63:	41 09 d0             	or     %edx,%r8d
  84dd66:	79 18                	jns    84dd80 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x1f0>
  84dd68:	48 83 c0 10          	add    $0x10,%rax
  84dd6c:	c5 f3 58 cb          	vaddsd %xmm3,%xmm1,%xmm1
  84dd70:	48 39 c1             	cmp    %rax,%rcx
  84dd73:	75 db                	jne    84dd50 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x1c0>
  84dd75:	e9 8d fe ff ff       	jmp    84dc07 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x77>
  84dd7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84dd80:	45 31 c0             	xor    %r8d,%r8d
  84dd83:	85 d2                	test   %edx,%edx
  84dd85:	41 0f 48 d0          	cmovs  %r8d,%edx
  84dd89:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84dd8e:	48 83 c0 10          	add    $0x10,%rax
  84dd92:	41 0f af d1          	imul   %r9d,%edx
  84dd96:	44 01 c2             	add    %r8d,%edx
  84dd99:	48 63 d2             	movslq %edx,%rdx
  84dd9c:	c5 fb 10 14 d7       	vmovsd (%rdi,%rdx,8),%xmm2
  84dda1:	c5 eb 59 50 f8       	vmulsd -0x8(%rax),%xmm2,%xmm2
  84dda6:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  84ddaa:	48 39 c8             	cmp    %rcx,%rax
  84ddad:	75 a1                	jne    84dd50 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x1c0>
  84ddaf:	e9 53 fe ff ff       	jmp    84dc07 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x77>
  84ddb4:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84ddbb:	00 00 00 
  84ddbe:	66 90                	xchg   %ax,%ax

000000000085dbf0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver]>:
  85dbf0:	55                   	push   %rbp
  85dbf1:	48 89 e5             	mov    %rsp,%rbp
  85dbf4:	e8 67 1c bf ff       	call   44f860 <__cpu_indicator_init>
  85dbf9:	8b 05 dd 56 16 00    	mov    0x1656dd(%rip),%eax        # 9c32dc <__cpu_model+0xc>
  85dbff:	f6 c4 80             	test   $0x80,%ah
  85dc02:	0f 84 85 28 be ff    	je     44048d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver] [clone .cold]>
  85dc08:	b8 80 d9 84 00       	mov    $0x84d980,%eax
  85dc0d:	5d                   	pop    %rbp
  85dc0e:	c3                   	ret    
  85dc0f:	90                   	nop

