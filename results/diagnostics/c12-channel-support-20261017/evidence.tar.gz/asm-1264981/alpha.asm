000000000044048d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver] [clone .cold]>:
  44048d:	f6 c4 04             	test   $0x4,%ah
  440490:	74 0a                	je     44049c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver] [clone .cold]+0xf>
  440492:	b8 60 da 84 00       	mov    $0x84da60,%eax
  440497:	e9 b1 d5 41 00       	jmp    85da4d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver]+0x1d>
  44049c:	b8 e0 d2 84 00       	mov    $0x84d2e0,%eax
  4404a1:	e9 a7 d5 41 00       	jmp    85da4d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver]+0x1d>

000000000084d2e0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]>:
  84d2e0:	55                   	push   %rbp
  84d2e1:	48 89 e5             	mov    %rsp,%rbp
  84d2e4:	48 c7 45 f8 00 00 00 	movq   $0x0,-0x8(%rbp)
  84d2eb:	00 
  84d2ec:	4c 8b 5d 10          	mov    0x10(%rbp),%r11
  84d2f0:	85 f6                	test   %esi,%esi
  84d2f2:	7e 62                	jle    84d356 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x76>
  84d2f4:	48 89 f8             	mov    %rdi,%rax
  84d2f7:	45 89 c2             	mov    %r8d,%r10d
  84d2fa:	48 89 d7             	mov    %rdx,%rdi
  84d2fd:	45 84 c0             	test   %r8b,%r8b
  84d300:	74 5e                	je     84d360 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x80>
  84d302:	41 83 f9 01          	cmp    $0x1,%r9d
  84d306:	0f 85 be 00 00 00    	jne    84d3ca <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xea>
  84d30c:	48 63 f6             	movslq %esi,%rsi
  84d30f:	66 0f ef d2          	pxor   %xmm2,%xmm2
  84d313:	48 c1 e6 04          	shl    $0x4,%rsi
  84d317:	48 8d 0c 06          	lea    (%rsi,%rax,1),%rcx
  84d31b:	31 f6                	xor    %esi,%esi
  84d31d:	0f 1f 00             	nopl   (%rax)
  84d320:	48 63 10             	movslq (%rax),%rdx
  84d323:	85 d2                	test   %edx,%edx
  84d325:	78 21                	js     84d348 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x68>
  84d327:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
  84d32b:	85 d2                	test   %edx,%edx
  84d32d:	78 19                	js     84d348 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x68>
  84d32f:	0f b7 70 04          	movzwl 0x4(%rax),%esi
  84d333:	48 01 f2             	add    %rsi,%rdx
  84d336:	44 89 d6             	mov    %r10d,%esi
  84d339:	f2 41 0f 10 0c d3    	movsd  (%r11,%rdx,8),%xmm1
  84d33f:	f2 0f 59 48 08       	mulsd  0x8(%rax),%xmm1
  84d344:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
  84d348:	48 83 c0 10          	add    $0x10,%rax
  84d34c:	48 39 c8             	cmp    %rcx,%rax
  84d34f:	75 cf                	jne    84d320 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x40>
  84d351:	40 84 f6             	test   %sil,%sil
  84d354:	75 68                	jne    84d3be <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xde>
  84d356:	f2 0f 58 45 f8       	addsd  -0x8(%rbp),%xmm0
  84d35b:	5d                   	pop    %rbp
  84d35c:	c3                   	ret    
  84d35d:	0f 1f 00             	nopl   (%rax)
  84d360:	48 63 f6             	movslq %esi,%rsi
  84d363:	66 0f ef d2          	pxor   %xmm2,%xmm2
  84d367:	48 c1 e6 04          	shl    $0x4,%rsi
  84d36b:	48 01 c6             	add    %rax,%rsi
  84d36e:	41 83 f9 01          	cmp    $0x1,%r9d
  84d372:	0f 85 a2 00 00 00    	jne    84d41a <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x13a>
  84d378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  84d37f:	00 
  84d380:	48 63 10             	movslq (%rax),%rdx
  84d383:	48 63 14 91          	movslq (%rcx,%rdx,4),%rdx
  84d387:	85 d2                	test   %edx,%edx
  84d389:	78 25                	js     84d3b0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xd0>
  84d38b:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
  84d38f:	85 d2                	test   %edx,%edx
  84d391:	78 1d                	js     84d3b0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xd0>
  84d393:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84d398:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  84d39e:	4c 01 c2             	add    %r8,%rdx
  84d3a1:	f2 41 0f 10 0c d3    	movsd  (%r11,%rdx,8),%xmm1
  84d3a7:	f2 0f 59 48 08       	mulsd  0x8(%rax),%xmm1
  84d3ac:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
  84d3b0:	48 83 c0 10          	add    $0x10,%rax
  84d3b4:	48 39 f0             	cmp    %rsi,%rax
  84d3b7:	75 c7                	jne    84d380 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xa0>
  84d3b9:	45 84 d2             	test   %r10b,%r10b
  84d3bc:	74 98                	je     84d356 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x76>
  84d3be:	f2 0f 11 55 f8       	movsd  %xmm2,-0x8(%rbp)
  84d3c3:	f2 0f 58 45 f8       	addsd  -0x8(%rbp),%xmm0
  84d3c8:	5d                   	pop    %rbp
  84d3c9:	c3                   	ret    
  84d3ca:	48 63 f6             	movslq %esi,%rsi
  84d3cd:	66 0f ef d2          	pxor   %xmm2,%xmm2
  84d3d1:	4d 63 c9             	movslq %r9d,%r9
  84d3d4:	48 c1 e6 04          	shl    $0x4,%rsi
  84d3d8:	48 8d 14 06          	lea    (%rsi,%rax,1),%rdx
  84d3dc:	31 f6                	xor    %esi,%esi
  84d3de:	66 90                	xchg   %ax,%ax
  84d3e0:	48 63 08             	movslq (%rax),%rcx
  84d3e3:	85 c9                	test   %ecx,%ecx
  84d3e5:	78 25                	js     84d40c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x12c>
  84d3e7:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
  84d3eb:	85 c9                	test   %ecx,%ecx
  84d3ed:	78 1d                	js     84d40c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x12c>
  84d3ef:	49 0f af c9          	imul   %r9,%rcx
  84d3f3:	0f b7 70 04          	movzwl 0x4(%rax),%esi
  84d3f7:	48 01 f1             	add    %rsi,%rcx
  84d3fa:	44 89 d6             	mov    %r10d,%esi
  84d3fd:	f2 41 0f 10 0c cb    	movsd  (%r11,%rcx,8),%xmm1
  84d403:	f2 0f 59 48 08       	mulsd  0x8(%rax),%xmm1
  84d408:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
  84d40c:	48 83 c0 10          	add    $0x10,%rax
  84d410:	48 39 d0             	cmp    %rdx,%rax
  84d413:	75 cb                	jne    84d3e0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x100>
  84d415:	e9 37 ff ff ff       	jmp    84d351 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x71>
  84d41a:	4d 63 c9             	movslq %r9d,%r9
  84d41d:	0f 1f 00             	nopl   (%rax)
  84d420:	48 63 10             	movslq (%rax),%rdx
  84d423:	48 63 14 91          	movslq (%rcx,%rdx,4),%rdx
  84d427:	85 d2                	test   %edx,%edx
  84d429:	78 29                	js     84d454 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x174>
  84d42b:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
  84d42f:	85 d2                	test   %edx,%edx
  84d431:	78 21                	js     84d454 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x174>
  84d433:	49 0f af d1          	imul   %r9,%rdx
  84d437:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84d43c:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  84d442:	4c 01 c2             	add    %r8,%rdx
  84d445:	f2 41 0f 10 0c d3    	movsd  (%r11,%rdx,8),%xmm1
  84d44b:	f2 0f 59 48 08       	mulsd  0x8(%rax),%xmm1
  84d450:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
  84d454:	48 83 c0 10          	add    $0x10,%rax
  84d458:	48 39 f0             	cmp    %rsi,%rax
  84d45b:	75 c3                	jne    84d420 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0x140>
  84d45d:	e9 57 ff ff ff       	jmp    84d3b9 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .default]+0xd9>
  84d462:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84d469:	00 00 00 
  84d46c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000084d8e0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]>:
  84d8e0:	55                   	push   %rbp
  84d8e1:	48 89 f8             	mov    %rdi,%rax
  84d8e4:	48 89 e5             	mov    %rsp,%rbp
  84d8e7:	48 83 e4 c0          	and    $0xffffffffffffffc0,%rsp
  84d8eb:	48 c7 44 24 c0 00 00 	movq   $0x0,-0x40(%rsp)
  84d8f2:	00 00 
  84d8f4:	48 8b 7d 10          	mov    0x10(%rbp),%rdi
  84d8f8:	85 f6                	test   %esi,%esi
  84d8fa:	7e 57                	jle    84d953 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x73>
  84d8fc:	45 89 c2             	mov    %r8d,%r10d
  84d8ff:	45 84 c0             	test   %r8b,%r8b
  84d902:	74 5c                	je     84d960 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x80>
  84d904:	41 83 f9 01          	cmp    $0x1,%r9d
  84d908:	0f 85 ba 00 00 00    	jne    84d9c8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xe8>
  84d90e:	48 63 f6             	movslq %esi,%rsi
  84d911:	45 31 c0             	xor    %r8d,%r8d
  84d914:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84d918:	48 c1 e6 04          	shl    $0x4,%rsi
  84d91c:	48 01 c6             	add    %rax,%rsi
  84d91f:	90                   	nop
  84d920:	48 63 08             	movslq (%rax),%rcx
  84d923:	85 c9                	test   %ecx,%ecx
  84d925:	78 1e                	js     84d945 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x65>
  84d927:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
  84d92b:	85 c9                	test   %ecx,%ecx
  84d92d:	78 16                	js     84d945 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x65>
  84d92f:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84d934:	c5 fb 10 58 08       	vmovsd 0x8(%rax),%xmm3
  84d939:	4c 01 c1             	add    %r8,%rcx
  84d93c:	45 89 d0             	mov    %r10d,%r8d
  84d93f:	c4 e2 e1 b9 0c cf    	vfmadd231sd (%rdi,%rcx,8),%xmm3,%xmm1
  84d945:	48 83 c0 10          	add    $0x10,%rax
  84d949:	48 39 c6             	cmp    %rax,%rsi
  84d94c:	75 d2                	jne    84d920 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x40>
  84d94e:	45 84 c0             	test   %r8b,%r8b
  84d951:	75 67                	jne    84d9ba <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xda>
  84d953:	c5 fb 58 44 24 c0    	vaddsd -0x40(%rsp),%xmm0,%xmm0
  84d959:	c9                   	leave  
  84d95a:	c3                   	ret    
  84d95b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  84d960:	48 63 f6             	movslq %esi,%rsi
  84d963:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84d967:	48 c1 e6 04          	shl    $0x4,%rsi
  84d96b:	4c 8d 04 06          	lea    (%rsi,%rax,1),%r8
  84d96f:	41 83 f9 01          	cmp    $0x1,%r9d
  84d973:	0f 85 9e 00 00 00    	jne    84da17 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x137>
  84d979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  84d980:	48 63 30             	movslq (%rax),%rsi
  84d983:	48 63 34 b1          	movslq (%rcx,%rsi,4),%rsi
  84d987:	85 f6                	test   %esi,%esi
  84d989:	78 21                	js     84d9ac <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xcc>
  84d98b:	48 63 34 b2          	movslq (%rdx,%rsi,4),%rsi
  84d98f:	85 f6                	test   %esi,%esi
  84d991:	78 19                	js     84d9ac <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xcc>
  84d993:	44 0f b7 48 04       	movzwl 0x4(%rax),%r9d
  84d998:	c5 fb 10 50 08       	vmovsd 0x8(%rax),%xmm2
  84d99d:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  84d9a3:	4c 01 ce             	add    %r9,%rsi
  84d9a6:	c4 e2 e9 b9 0c f7    	vfmadd231sd (%rdi,%rsi,8),%xmm2,%xmm1
  84d9ac:	48 83 c0 10          	add    $0x10,%rax
  84d9b0:	49 39 c0             	cmp    %rax,%r8
  84d9b3:	75 cb                	jne    84d980 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xa0>
  84d9b5:	45 84 d2             	test   %r10b,%r10b
  84d9b8:	74 99                	je     84d953 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x73>
  84d9ba:	c5 fb 11 4c 24 c0    	vmovsd %xmm1,-0x40(%rsp)
  84d9c0:	c5 fb 58 44 24 c0    	vaddsd -0x40(%rsp),%xmm0,%xmm0
  84d9c6:	c9                   	leave  
  84d9c7:	c3                   	ret    
  84d9c8:	48 63 f6             	movslq %esi,%rsi
  84d9cb:	45 31 c0             	xor    %r8d,%r8d
  84d9ce:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  84d9d2:	4d 63 c9             	movslq %r9d,%r9
  84d9d5:	48 c1 e6 04          	shl    $0x4,%rsi
  84d9d9:	48 8d 0c 06          	lea    (%rsi,%rax,1),%rcx
  84d9dd:	0f 1f 00             	nopl   (%rax)
  84d9e0:	48 63 30             	movslq (%rax),%rsi
  84d9e3:	85 f6                	test   %esi,%esi
  84d9e5:	78 22                	js     84da09 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x129>
  84d9e7:	48 63 34 b2          	movslq (%rdx,%rsi,4),%rsi
  84d9eb:	85 f6                	test   %esi,%esi
  84d9ed:	78 1a                	js     84da09 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x129>
  84d9ef:	49 0f af f1          	imul   %r9,%rsi
  84d9f3:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84d9f8:	c5 fb 10 68 08       	vmovsd 0x8(%rax),%xmm5
  84d9fd:	4c 01 c6             	add    %r8,%rsi
  84da00:	45 89 d0             	mov    %r10d,%r8d
  84da03:	c4 e2 d1 b9 0c f7    	vfmadd231sd (%rdi,%rsi,8),%xmm5,%xmm1
  84da09:	48 83 c0 10          	add    $0x10,%rax
  84da0d:	48 39 c1             	cmp    %rax,%rcx
  84da10:	75 ce                	jne    84d9e0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x100>
  84da12:	e9 37 ff ff ff       	jmp    84d94e <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x6e>
  84da17:	4d 63 c9             	movslq %r9d,%r9
  84da1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84da20:	48 63 30             	movslq (%rax),%rsi
  84da23:	48 63 34 b1          	movslq (%rcx,%rsi,4),%rsi
  84da27:	85 f6                	test   %esi,%esi
  84da29:	78 25                	js     84da50 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x170>
  84da2b:	48 63 34 b2          	movslq (%rdx,%rsi,4),%rsi
  84da2f:	85 f6                	test   %esi,%esi
  84da31:	78 1d                	js     84da50 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x170>
  84da33:	49 0f af f1          	imul   %r9,%rsi
  84da37:	44 0f b7 50 04       	movzwl 0x4(%rax),%r10d
  84da3c:	c5 fb 10 60 08       	vmovsd 0x8(%rax),%xmm4
  84da41:	4c 01 d6             	add    %r10,%rsi
  84da44:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  84da4a:	c4 e2 d9 b9 0c f7    	vfmadd231sd (%rdi,%rsi,8),%xmm4,%xmm1
  84da50:	48 83 c0 10          	add    $0x10,%rax
  84da54:	4c 39 c0             	cmp    %r8,%rax
  84da57:	75 c7                	jne    84da20 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0x140>
  84da59:	e9 57 ff ff ff       	jmp    84d9b5 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx512f]+0xd5>
  84da5e:	66 90                	xchg   %ax,%ax

000000000084da60 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]>:
  84da60:	55                   	push   %rbp
  84da61:	48 89 e5             	mov    %rsp,%rbp
  84da64:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
  84da68:	48 c7 44 24 e0 00 00 	movq   $0x0,-0x20(%rsp)
  84da6f:	00 00 
  84da71:	4c 8b 5d 10          	mov    0x10(%rbp),%r11
  84da75:	85 f6                	test   %esi,%esi
  84da77:	7e 65                	jle    84dade <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x7e>
  84da79:	48 89 f8             	mov    %rdi,%rax
  84da7c:	45 89 c2             	mov    %r8d,%r10d
  84da7f:	48 89 d7             	mov    %rdx,%rdi
  84da82:	45 84 c0             	test   %r8b,%r8b
  84da85:	74 69                	je     84daf0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x90>
  84da87:	41 83 f9 01          	cmp    $0x1,%r9d
  84da8b:	0f 85 cb 00 00 00    	jne    84db5c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xfc>
  84da91:	48 63 f6             	movslq %esi,%rsi
  84da94:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  84da98:	48 c1 e6 04          	shl    $0x4,%rsi
  84da9c:	48 8d 0c 06          	lea    (%rsi,%rax,1),%rcx
  84daa0:	31 f6                	xor    %esi,%esi
  84daa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  84daa8:	48 63 10             	movslq (%rax),%rdx
  84daab:	85 d2                	test   %edx,%edx
  84daad:	78 21                	js     84dad0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x70>
  84daaf:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
  84dab3:	85 d2                	test   %edx,%edx
  84dab5:	78 19                	js     84dad0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x70>
  84dab7:	0f b7 70 04          	movzwl 0x4(%rax),%esi
  84dabb:	48 01 f2             	add    %rsi,%rdx
  84dabe:	44 89 d6             	mov    %r10d,%esi
  84dac1:	c4 c1 7b 10 0c d3    	vmovsd (%r11,%rdx,8),%xmm1
  84dac7:	c5 f3 59 48 08       	vmulsd 0x8(%rax),%xmm1,%xmm1
  84dacc:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  84dad0:	48 83 c0 10          	add    $0x10,%rax
  84dad4:	48 39 c1             	cmp    %rax,%rcx
  84dad7:	75 cf                	jne    84daa8 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x48>
  84dad9:	40 84 f6             	test   %sil,%sil
  84dadc:	75 70                	jne    84db4e <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xee>
  84dade:	c5 fb 58 44 24 e0    	vaddsd -0x20(%rsp),%xmm0,%xmm0
  84dae4:	c9                   	leave  
  84dae5:	c3                   	ret    
  84dae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84daed:	00 00 00 
  84daf0:	48 63 f6             	movslq %esi,%rsi
  84daf3:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  84daf7:	48 c1 e6 04          	shl    $0x4,%rsi
  84dafb:	48 01 c6             	add    %rax,%rsi
  84dafe:	41 83 f9 01          	cmp    $0x1,%r9d
  84db02:	0f 85 a2 00 00 00    	jne    84dbaa <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x14a>
  84db08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  84db0f:	00 
  84db10:	48 63 10             	movslq (%rax),%rdx
  84db13:	48 63 14 91          	movslq (%rcx,%rdx,4),%rdx
  84db17:	85 d2                	test   %edx,%edx
  84db19:	78 25                	js     84db40 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xe0>
  84db1b:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
  84db1f:	85 d2                	test   %edx,%edx
  84db21:	78 1d                	js     84db40 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xe0>
  84db23:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84db28:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  84db2e:	4c 01 c2             	add    %r8,%rdx
  84db31:	c4 c1 7b 10 0c d3    	vmovsd (%r11,%rdx,8),%xmm1
  84db37:	c5 f3 59 48 08       	vmulsd 0x8(%rax),%xmm1,%xmm1
  84db3c:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  84db40:	48 83 c0 10          	add    $0x10,%rax
  84db44:	48 39 c6             	cmp    %rax,%rsi
  84db47:	75 c7                	jne    84db10 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xb0>
  84db49:	45 84 d2             	test   %r10b,%r10b
  84db4c:	74 90                	je     84dade <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x7e>
  84db4e:	c5 fb 11 54 24 e0    	vmovsd %xmm2,-0x20(%rsp)
  84db54:	c5 fb 58 44 24 e0    	vaddsd -0x20(%rsp),%xmm0,%xmm0
  84db5a:	c9                   	leave  
  84db5b:	c3                   	ret    
  84db5c:	48 63 f6             	movslq %esi,%rsi
  84db5f:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  84db63:	4d 63 c9             	movslq %r9d,%r9
  84db66:	48 c1 e6 04          	shl    $0x4,%rsi
  84db6a:	48 8d 14 06          	lea    (%rsi,%rax,1),%rdx
  84db6e:	31 f6                	xor    %esi,%esi
  84db70:	48 63 08             	movslq (%rax),%rcx
  84db73:	85 c9                	test   %ecx,%ecx
  84db75:	78 25                	js     84db9c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x13c>
  84db77:	48 63 0c 8f          	movslq (%rdi,%rcx,4),%rcx
  84db7b:	85 c9                	test   %ecx,%ecx
  84db7d:	78 1d                	js     84db9c <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x13c>
  84db7f:	49 0f af c9          	imul   %r9,%rcx
  84db83:	0f b7 70 04          	movzwl 0x4(%rax),%esi
  84db87:	48 01 f1             	add    %rsi,%rcx
  84db8a:	44 89 d6             	mov    %r10d,%esi
  84db8d:	c4 c1 7b 10 0c cb    	vmovsd (%r11,%rcx,8),%xmm1
  84db93:	c5 f3 59 48 08       	vmulsd 0x8(%rax),%xmm1,%xmm1
  84db98:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  84db9c:	48 83 c0 10          	add    $0x10,%rax
  84dba0:	48 39 c2             	cmp    %rax,%rdx
  84dba3:	75 cb                	jne    84db70 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x110>
  84dba5:	e9 2f ff ff ff       	jmp    84dad9 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x79>
  84dbaa:	4d 63 c9             	movslq %r9d,%r9
  84dbad:	0f 1f 00             	nopl   (%rax)
  84dbb0:	48 63 10             	movslq (%rax),%rdx
  84dbb3:	48 63 14 91          	movslq (%rcx,%rdx,4),%rdx
  84dbb7:	85 d2                	test   %edx,%edx
  84dbb9:	78 29                	js     84dbe4 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x184>
  84dbbb:	48 63 14 97          	movslq (%rdi,%rdx,4),%rdx
  84dbbf:	85 d2                	test   %edx,%edx
  84dbc1:	78 21                	js     84dbe4 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x184>
  84dbc3:	49 0f af d1          	imul   %r9,%rdx
  84dbc7:	44 0f b7 40 04       	movzwl 0x4(%rax),%r8d
  84dbcc:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  84dbd2:	4c 01 c2             	add    %r8,%rdx
  84dbd5:	c4 c1 7b 10 0c d3    	vmovsd (%r11,%rdx,8),%xmm1
  84dbdb:	c5 f3 59 48 08       	vmulsd 0x8(%rax),%xmm1,%xmm1
  84dbe0:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  84dbe4:	48 83 c0 10          	add    $0x10,%rax
  84dbe8:	48 39 c6             	cmp    %rax,%rsi
  84dbeb:	75 c3                	jne    84dbb0 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0x150>
  84dbed:	e9 57 ff ff ff       	jmp    84db49 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .avx2]+0xe9>
  84dbf2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  84dbf9:	00 00 00 
  84dbfc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000085da30 <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver]>:
  85da30:	55                   	push   %rbp
  85da31:	48 89 e5             	mov    %rsp,%rbp
  85da34:	e8 27 1e bf ff       	call   44f860 <__cpu_indicator_init>
  85da39:	8b 05 9d 58 16 00    	mov    0x16589d(%rip),%eax        # 9c32dc <__cpu_model+0xc>
  85da3f:	f6 c4 80             	test   $0x80,%ah
  85da42:	0f 84 45 2a be ff    	je     44048d <xmvb::mcscf::(anonymous namespace)::alpha_transpose_dot(xmvb::mcscf::DensityConnections, int const*, int const*, bool, int, double const*, double) [clone .resolver] [clone .cold]>
  85da48:	b8 e0 d8 84 00       	mov    $0x84d8e0,%eax
  85da4d:	5d                   	pop    %rbp
  85da4e:	c3                   	ret    
  85da4f:	90                   	nop

