/** @file Exact channel-support census; no production operator is modified. */
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include "mcscf/ci/product_support.hpp"
#include "mcscf/ci/sigma.hpp"
#include "parallel/openmp.hpp"

namespace {
using Bits=std::uint64_t;
using Channels=std::array<Bits,2>;
using Support=xmvb::mcscf::ProductSupport;
using Matrix=Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic,Eigen::RowMajor>;

/** @brief Diagnostic exact-zero SpMM prototype; emits every output channel. */
#if defined(__GNUC__) && !defined(__clang__) && defined(__x86_64__)
__attribute__((target_clones("avx512f", "avx2", "default")))
#endif
void sparse_product(const double* __restrict source,const double* __restrict kernel,
    double* __restrict output,int rows,int pairs) {
  for (int row=0;row<rows;++row) {
    double* target=output+static_cast<std::size_t>(row)*pairs;
    std::fill_n(target,pairs,0.0);
    for (int q=0;q<pairs;++q) {
      const double value=source[static_cast<std::size_t>(row)*pairs+q];
      if (value==0.0) continue;
      const double* column=kernel+static_cast<std::size_t>(q)*pairs;
#pragma omp simd
      for (int p=0;p<pairs;++p) target[p]+=value*column[p];
    }
  }
}

struct Products {
  double dense_s=0,sparse_s=0,error=0;
  std::uint64_t rows=0;
  void consume(const std::vector<Channels>& masks) {
    constexpr int pairs=78;
    const int count=masks.size(),workers=xmvb::effective_openmp_thread_count();
    // Three shared channel slabs only, at most 58.5 MiB at 32768 rows.
    Matrix source(count,pairs),dense(count,pairs),sparse(count,pairs);
    Eigen::MatrixXd kernel(pairs,pairs);
    for (int q=0;q<pairs;++q) for (int p=0;p<pairs;++p)
      kernel(p,q)=std::cos(0.003*(p+1)*(q+2));
#pragma omp parallel for schedule(static) num_threads(workers)
    for (int row=0;row<count;++row) for (int p=0;p<pairs;++p)
      source(row,p)=masks[row][p/64]&(Bits{1}<<(p%64)) ?
          1.25+std::sin(0.013*(row+1)*(p+1)):0.0;
    const auto apply=[&](bool compressed) {
#pragma omp parallel for schedule(static) num_threads(workers)
      for (int part=0;part<workers;++part) {
        const int first=count*part/workers,last=count*(part+1)/workers;
        if (compressed) sparse_product(source.data()+static_cast<std::size_t>(first)*pairs,
            kernel.data(),sparse.data()+static_cast<std::size_t>(first)*pairs,last-first,pairs);
        else dense.middleRows(first,last-first).noalias()=
            source.middleRows(first,last-first)*kernel.transpose();
      }
    };
    apply(false); apply(true); // Warm both current-reference and prototype paths.
    using Clock=std::chrono::steady_clock;
    const auto start=Clock::now(); apply(false); const auto middle=Clock::now();
    apply(true); const auto end=Clock::now();
    dense_s+=std::chrono::duration<double>(middle-start).count();
    sparse_s+=std::chrono::duration<double>(end-middle).count();
    const double relative=(dense-sparse).norm()/std::max(1.0,dense.norm());
    error=std::max(error,relative); rows+=count;
    if (relative>1e-12) throw std::runtime_error("sparse full-output product changed K*A");
  }
};

/** @brief Fixed-spin strings in occupied-orbital lexicographic order. */
void append_strings(int n,int left,int first,Bits mask,std::vector<Bits>& result) {
  if (!left) { result.push_back(mask); return; }
  for (int p=first;p<=n-left;++p)
    append_strings(n,left-1,p+1,mask|(Bits{1}<<p),result);
}

struct Sector {
  std::vector<Bits> strings;
  std::unordered_map<Bits,int> index;
  Sector(int n,int electrons) {
    append_strings(n,electrons,0,0,strings);
    for (int i=0;i<static_cast<int>(strings.size());++i) index.emplace(strings[i],i);
  }
  std::vector<std::vector<int>> occupations(int n) const {
    std::vector<std::vector<int>> result(strings.size());
    for (std::size_t i=0;i<strings.size();++i)
      for (int p=0;p<n;++p) if (strings[i]&(Bits{1}<<p)) result[i].push_back(p);
    return result;
  }
};

/** @brief Channels with a preimage in S, independent of numerical amplitudes. */
Channels channels(const Support& support,const Sector& alpha,const Sector& beta,
    int n,int a,int b) {
  Channels result{};
  const Bits am=alpha.strings[a],bm=beta.strings[b];
  const bool own=support.contains(a,b);
  for (int p=0;p<n;++p) for (int q=0;q<=p;++q) {
    const Bits flip=(Bits{1}<<p)|(Bits{1}<<q);
    const auto changes=[&](Bits value) {
      return ((value>>p)&1)!=((value>>q)&1);
    };
    const bool live=p==q ? own && ((am|bm)&(Bits{1}<<p)) :
        (changes(am) && support.contains(alpha.index.at(am^flip),b)) ||
        (changes(bm) && support.contains(a,beta.index.at(bm^flip)));
    if (live) {
      const int pair=p*(p+1)/2+q;
      result[pair/64]|=Bits{1}<<(pair%64);
    }
  }
  return result;
}

/** @brief Small complete-carrier oracle using the production generator action. */
void check_channels() {
  constexpr int n=4,pairs=10;
  for (const auto [na,nb]:{std::pair{2,2},std::pair{1,3},std::pair{0,4}}) {
    const Sector alpha(n,na),beta(n,nb);
    const Support support(n,alpha.strings,beta.strings);
    const xmvb::mcscf::ActiveIntegrals integrals{
        Eigen::MatrixXd::Zero(n,n),Eigen::MatrixXd::Zero(pairs,pairs)};
    const xmvb::mcscf::DirectCiSigmaAction sigma(
        alpha.occupations(n),beta.occupations(n),integrals);
    const int rows=alpha.strings.size(),cols=beta.strings.size();
    // Only this n=4 oracle has complete product arrays (at most 36 entries).
    std::vector<Channels> observed(rows*cols);
    for (int sa=0;sa<rows;++sa) for (int sb=0;sb<cols;++sb) {
      if (!support.contains(sa,sb)) continue;
      Eigen::MatrixXd seed=Eigen::MatrixXd::Zero(rows,cols); seed(sa,sb)=1;
      for (int p=0;p<n;++p) for (int q=0;q<=p;++q) {
        Eigen::MatrixXd generator=Eigen::MatrixXd::Zero(n,n);
        generator(p,q)=generator(q,p)=1;
        const auto image=sigma.apply_one_body_generator(seed,generator);
        const int pair=p*(p+1)/2+q;
        for (int a=0;a<rows;++a) for (int b=0;b<cols;++b)
          if (image(a,b)!=0) observed[a*cols+b][pair/64]|=Bits{1}<<(pair%64);
      }
    }
    for (int a=0;a<rows;++a) for (int b=0;b<cols;++b)
      if (observed[a*cols+b]!=channels(support,alpha,beta,n,a,b))
        throw std::runtime_error("channel support differs from generator basis actions");
  }
  std::cout << "small_generator_oracle=PASS\n";
}

/** @brief Tile-bounded grouping census: never retain a product-space mask. */
void census(const std::string& space,int tile_rows,bool benchmark) {
  constexpr int n=12,pairs=n*(n+1)/2;
  const Sector alpha(n,6),beta(n,6);
  const auto make_support=[&]() {
    if (space=="cov") return Support(n,alpha.strings,beta.strings);
    std::vector<xmvb::mcscf::ProductIndex> seeds;
    if (space=="full") {
      const int top=alpha.index.at(((Bits{1}<<6)-1)<<6);
      seeds.push_back(top*static_cast<int>(beta.strings.size())+top);
    } else if (space=="single") {
      // One singlet product of six disjoint pairs: original support has 2^6 terms.
      for (Bits choices=0;choices<(Bits{1}<<6);++choices) {
        Bits a=0;
        for (int p=0;p<6;++p) a|=Bits{1}<<(2*p+((choices>>p)&1));
        const Bits b=((Bits{1}<<n)-1)^a;
        seeds.push_back(alpha.index.at(a)*static_cast<int>(beta.strings.size())+beta.index.at(b));
      }
    } else throw std::invalid_argument("unknown support family");
    return Support(n,alpha.strings,beta.strings,seeds);
  };
  const Support support=make_support();
  std::array<std::uint64_t,pairs+1> widths{};
  std::array<std::uint64_t,64> group_sizes{};
  std::map<Channels,std::uint64_t> groups;
  std::vector<Channels> masks;
  Products products;
  std::uint64_t targets=0,source_targets=0,sum_width=0,sum_square=0,batches=0,
      group_count=0,largest_group=0,peak_groups=0;
  int live=0;
  const auto flush=[&]() {
    if (!live) return;
    ++batches;
    group_count+=groups.size(); peak_groups=std::max<std::uint64_t>(peak_groups,groups.size());
    for (const auto& [mask,count]:groups) {
      ++group_sizes[std::bit_width(count)-1];
      largest_group=std::max(largest_group,count);
    }
    if (benchmark) { products.consume(masks); masks.clear(); }
    groups.clear(); live=0;
  };
  auto cursor=support.cursor(1); int a,b; bool in_support;
  while (cursor.next(a,b,in_support)) {
    if (a>b) continue; // The production even-exchange representative.
    const auto mask=channels(support,alpha,beta,n,a,b);
    const auto width=std::popcount(mask[0])+std::popcount(mask[1]);
    ++targets; source_targets+=in_support; ++widths[width];
    sum_width+=width; sum_square+=width*width;
    ++groups[mask];
    if (benchmark) masks.push_back(mask);
    if (++live==tile_rows) flush();
  }
  flush();
  std::cout << std::setprecision(12) << "space=" << space << " tile_rows=" << tile_rows
      << " targets=" << targets << " source_targets=" << source_targets
      << " mean_channels=" << static_cast<double>(sum_width)/targets
      << " universal_gemm_work_ratio=" << static_cast<double>(sum_width)/(targets*pairs)
      << " gram_work_ratio=" << static_cast<double>(sum_square)/(targets*pairs*pairs)
      << " groups=" << group_count << " mean_group_rows=" << static_cast<double>(targets)/group_count
      << " largest_group=" << largest_group << " peak_tile_groups=" << peak_groups
      << " batches=" << batches << '\n';
  if (benchmark)
    std::cout << "product_probe," << space << ",rows=" << products.rows
        << ",threads=" << xmvb::effective_openmp_thread_count()
        << ",dense_s=" << products.dense_s << ",exact_zero_spmm_s=" << products.sparse_s
        << ",relative_error=" << products.error << '\n';
  for (int k=0;k<=pairs;++k) if (widths[k])
    std::cout << "width," << space << ',' << tile_rows << ',' << k << ',' << widths[k] << '\n';
  for (int k=0;k<64;++k) if (group_sizes[k])
    std::cout << "group_rows_bin," << space << ',' << tile_rows << ',' << (Bits{1}<<k)
              << ',' << group_sizes[k] << '\n';
}
} // namespace

int main() {
  check_channels();
  for (const int tile_rows:{4096,32768})
    for (const auto* space:{"single","cov","full"}) census(space,tile_rows,tile_rows==32768);
}
