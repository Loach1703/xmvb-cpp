
build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

Disassembly of section .fini:

build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

Disassembly of section .fini:

build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

Disassembly of section .fini:

build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

Disassembly of section .fini:
