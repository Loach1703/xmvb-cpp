
build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000905c10 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE>:
  905c10:	55                   	push   %rbp
  905c11:	48 89 e5             	mov    %rsp,%rbp
  905c14:	41 57                	push   %r15
  905c16:	41 56                	push   %r14
  905c18:	41 55                	push   %r13
  905c1a:	41 54                	push   %r12
  905c1c:	53                   	push   %rbx
  905c1d:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
  905c24:	48 89 bd d8 fe ff ff 	mov    %rdi,-0x128(%rbp)
  905c2b:	48 89 b5 f0 fe ff ff 	mov    %rsi,-0x110(%rbp)
  905c32:	48 89 95 f8 fe ff ff 	mov    %rdx,-0x108(%rbp)
  905c39:	c7 85 10 ff ff ff 20 	movl   $0x20,-0xf0(%rbp)
  905c40:	00 00 00 
  905c43:	0f b6 05 ae 0d 0a 00 	movzbl 0xa0dae(%rip),%eax        # 9a69f8 <_ZGVZN4xmvb9profiling12phase_totalsEvE6totals>
  905c4a:	84 c0                	test   %al,%al
  905c4c:	0f 84 43 07 00 00    	je     906395 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x785>
  905c52:	0f b6 05 a7 0d 0a 00 	movzbl 0xa0da7(%rip),%eax        # 9a6a00 <_ZZN4xmvb9profiling12phase_totalsEvE6totals>
  905c59:	66 0f ef c0          	pxor   %xmm0,%xmm0
  905c5d:	c6 85 15 ff ff ff 00 	movb   $0x0,-0xeb(%rbp)
  905c64:	0f 11 85 18 ff ff ff 	movups %xmm0,-0xe8(%rbp)
  905c6b:	88 85 14 ff ff ff    	mov    %al,-0xec(%rbp)
  905c71:	84 c0                	test   %al,%al
  905c73:	74 18                	je     905c8d <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x7d>
  905c75:	e8 e6 1f b0 ff       	call   407c60 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  905c7a:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
  905c81:	e8 ea 13 b0 ff       	call   407070 <clock@plt>
  905c86:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
  905c8d:	48 8b 9d f8 fe ff ff 	mov    -0x108(%rbp),%rbx
  905c94:	48 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdx
  905c9b:	aa aa aa 
  905c9e:	48 8b 43 08          	mov    0x8(%rbx),%rax
  905ca2:	48 2b 03             	sub    (%rbx),%rax
  905ca5:	48 c1 f8 03          	sar    $0x3,%rax
  905ca9:	48 0f af c2          	imul   %rdx,%rax
  905cad:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
  905cb4:	89 85 bc fe ff ff    	mov    %eax,-0x144(%rbp)
  905cba:	48 98                	cltq   
  905cbc:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
  905cc3:	48 c1 e8 3c          	shr    $0x3c,%rax
  905cc7:	0f 85 bf 5c b4 ff    	jne    44b98c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold>
  905ccd:	66 0f ef c0          	pxor   %xmm0,%xmm0
  905cd1:	48 83 bd c8 fe ff ff 	cmpq   $0x0,-0x138(%rbp)
  905cd8:	00 
  905cd9:	48 c7 85 40 ff ff ff 	movq   $0x0,-0xc0(%rbp)
  905ce0:	00 00 00 00 
  905ce4:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
  905ceb:	0f 84 62 06 00 00    	je     906353 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x743>
  905cf1:	4c 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%r15
  905cf8:	4e 8d 2c fd 00 00 00 	lea    0x0(,%r15,8),%r13
  905cff:	00 
  905d00:	4c 89 ef             	mov    %r13,%rdi
  905d03:	e8 c8 14 b0 ff       	call   4071d0 <_Znwm@plt>
  905d08:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  905d0f:	4e 8d 24 28          	lea    (%rax,%r13,1),%r12
  905d13:	48 8d 78 08          	lea    0x8(%rax),%rdi
  905d17:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
  905d1e:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  905d25:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
  905d2c:	48 8b 58 08          	mov    0x8(%rax),%rbx
  905d30:	48 2b 18             	sub    (%rax),%rbx
  905d33:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
  905d3a:	aa aa aa 
  905d3d:	48 c1 fb 03          	sar    $0x3,%rbx
  905d41:	48 0f af d8          	imul   %rax,%rbx
  905d45:	49 83 ff 01          	cmp    $0x1,%r15
  905d49:	74 0e                	je     905d59 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x149>
  905d4b:	49 8d 55 f8          	lea    -0x8(%r13),%rdx
  905d4f:	31 f6                	xor    %esi,%esi
  905d51:	e8 4a 16 b0 ff       	call   4073a0 <memset@plt>
  905d56:	4c 89 e7             	mov    %r12,%rdi
  905d59:	48 8d 45 80          	lea    -0x80(%rbp),%rax
  905d5d:	48 89 bd 38 ff ff ff 	mov    %rdi,-0xc8(%rbp)
  905d64:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
  905d6b:	48 c7 85 58 ff ff ff 	movq   $0x1,-0xa8(%rbp)
  905d72:	01 00 00 00 
  905d76:	48 c7 85 60 ff ff ff 	movq   $0x0,-0xa0(%rbp)
  905d7d:	00 00 00 00 
  905d81:	48 c7 85 68 ff ff ff 	movq   $0x0,-0x98(%rbp)
  905d88:	00 00 00 00 
  905d8c:	c7 85 70 ff ff ff 00 	movl   $0x3f800000,-0x90(%rbp)
  905d93:	00 80 3f 
  905d96:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
  905d9d:	00 00 00 00 
  905da1:	48 c7 45 80 00 00 00 	movq   $0x0,-0x80(%rbp)
  905da8:	00 
  905da9:	48 85 db             	test   %rbx,%rbx
  905dac:	0f 88 c5 05 00 00    	js     906377 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x767>
  905db2:	66 0f ef c0          	pxor   %xmm0,%xmm0
  905db6:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
  905dbb:	f2 0f 10 0d a5 73 03 	movsd  0x373a5(%rip),%xmm1        # 93d168 <_ZTSZN4xmvb2vb40solve_nonredundant_truncated_newton_stepERKNS0_28NonredundantRetractionMetricERKNS0_12OrbitalChartERKNS4_16ProjectionResultEddddPNS0_10ReducedHvpEPKNS0_37TransportedReducedLbfgsPreconditionerEPKN5Eigen6MatrixIdLin1ELi1ELi0ELin1ELi1EEEPKNS0_23TruncatedNewtonSubspaceEEUlRSI_E_+0x1328>
  905dc2:	00 
  905dc3:	66 0f 2f c1          	comisd %xmm1,%xmm0
  905dc7:	0f 83 22 05 00 00    	jae    9062ef <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x6df>
  905dcd:	f2 48 0f 2c f0       	cvttsd2si %xmm0,%rsi
  905dd2:	48 85 f6             	test   %rsi,%rsi
  905dd5:	b8 01 00 00 00       	mov    $0x1,%eax
  905dda:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
  905de1:	48 0f 44 f0          	cmove  %rax,%rsi
  905de5:	e8 56 1b b0 ff       	call   407940 <_ZNKSt8__detail20_Prime_rehash_policy11_M_next_bktEm@plt>
  905dea:	48 3b 85 58 ff ff ff 	cmp    -0xa8(%rbp),%rax
  905df1:	0f 85 48 05 00 00    	jne    90633f <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x72f>
  905df7:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
  905dfe:	00 00 00 00 
  905e02:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
  905e09:	45 31 f6             	xor    %r14d,%r14d
  905e0c:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  905e12:	8d 58 ff             	lea    -0x1(%rax),%ebx
  905e15:	48 89 9d e0 fe ff ff 	mov    %rbx,-0x120(%rbp)
  905e1c:	85 c0                	test   %eax,%eax
  905e1e:	0f 84 ec 01 00 00    	je     906010 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x400>
  905e24:	0f 1f 40 00          	nopl   0x0(%rax)
  905e28:	48 8b 9d f8 fe ff ff 	mov    -0x108(%rbp),%rbx
  905e2f:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
  905e36:	45 89 f7             	mov    %r14d,%r15d
  905e39:	31 f6                	xor    %esi,%esi
  905e3b:	48 8b 13             	mov    (%rbx),%rdx
  905e3e:	44 8b 18             	mov    (%rax),%r11d
  905e41:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  905e45:	48 8d 14 c2          	lea    (%rdx,%rax,8),%rdx
  905e49:	48 8b 02             	mov    (%rdx),%rax
  905e4c:	4c 8b 52 08          	mov    0x8(%rdx),%r10
  905e50:	4c 39 d0             	cmp    %r10,%rax
  905e53:	74 3f                	je     905e94 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x284>
  905e55:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  905e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  905e60:	89 cf                	mov    %ecx,%edi
  905e62:	8b 08                	mov    (%rax),%ecx
  905e64:	41 89 c8             	mov    %ecx,%r8d
  905e67:	41 c1 e8 1f          	shr    $0x1f,%r8d
  905e6b:	41 39 cb             	cmp    %ecx,%r11d
  905e6e:	0f 9e c2             	setle  %dl
  905e71:	44 08 c2             	or     %r8b,%dl
  905e74:	0f 85 d2 5b b4 ff    	jne    44ba4c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xc0>
  905e7a:	39 cf                	cmp    %ecx,%edi
  905e7c:	0f 8d ca 5b b4 ff    	jge    44ba4c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xc0>
  905e82:	4c 89 e2             	mov    %r12,%rdx
  905e85:	48 83 c0 04          	add    $0x4,%rax
  905e89:	48 d3 e2             	shl    %cl,%rdx
  905e8c:	48 09 d6             	or     %rdx,%rsi
  905e8f:	49 39 c2             	cmp    %rax,%r10
  905e92:	75 cc                	jne    905e60 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x250>
  905e94:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
  905e9b:	bf 18 00 00 00       	mov    $0x18,%edi
  905ea0:	4a 8d 1c f0          	lea    (%rax,%r14,8),%rbx
  905ea4:	48 89 33             	mov    %rsi,(%rbx)
  905ea7:	e8 24 13 b0 ff       	call   4071d0 <_Znwm@plt>
  905eac:	48 8b 1b             	mov    (%rbx),%rbx
  905eaf:	4c 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%r10
  905eb6:	44 89 78 10          	mov    %r15d,0x10(%rax)
  905eba:	49 89 c5             	mov    %rax,%r13
  905ebd:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  905ec4:	48 89 58 08          	mov    %rbx,0x8(%rax)
  905ec8:	4d 85 d2             	test   %r10,%r10
  905ecb:	75 33                	jne    905f00 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x2f0>
  905ecd:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
  905ed4:	48 85 c0             	test   %rax,%rax
  905ed7:	75 13                	jne    905eec <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x2dc>
  905ed9:	e9 12 01 00 00       	jmp    905ff0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x3e0>
  905ede:	66 90                	xchg   %ax,%ax
  905ee0:	48 8b 00             	mov    (%rax),%rax
  905ee3:	48 85 c0             	test   %rax,%rax
  905ee6:	0f 84 04 01 00 00    	je     905ff0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x3e0>
  905eec:	48 3b 58 08          	cmp    0x8(%rax),%rbx
  905ef0:	75 ee                	jne    905ee0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x2d0>
  905ef2:	e9 f1 5a b4 ff       	jmp    44b9e8 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x5c>
  905ef7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  905efe:	00 00 
  905f00:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  905f07:	48 89 d8             	mov    %rbx,%rax
  905f0a:	31 d2                	xor    %edx,%edx
  905f0c:	48 f7 f6             	div    %rsi
  905f0f:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
  905f16:	4c 8b 3c d0          	mov    (%rax,%rdx,8),%r15
  905f1a:	49 89 d3             	mov    %rdx,%r11
  905f1d:	49 89 d1             	mov    %rdx,%r9
  905f20:	4d 85 ff             	test   %r15,%r15
  905f23:	74 3b                	je     905f60 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x350>
  905f25:	49 8b 07             	mov    (%r15),%rax
  905f28:	48 8b 48 08          	mov    0x8(%rax),%rcx
  905f2c:	48 39 cb             	cmp    %rcx,%rbx
  905f2f:	74 24                	je     905f55 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x345>
  905f31:	48 8b 38             	mov    (%rax),%rdi
  905f34:	48 85 ff             	test   %rdi,%rdi
  905f37:	74 27                	je     905f60 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x350>
  905f39:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
  905f3d:	49 89 c7             	mov    %rax,%r15
  905f40:	31 d2                	xor    %edx,%edx
  905f42:	48 89 c8             	mov    %rcx,%rax
  905f45:	48 f7 f6             	div    %rsi
  905f48:	4c 39 da             	cmp    %r11,%rdx
  905f4b:	75 13                	jne    905f60 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x350>
  905f4d:	48 89 f8             	mov    %rdi,%rax
  905f50:	48 39 cb             	cmp    %rcx,%rbx
  905f53:	75 dc                	jne    905f31 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x321>
  905f55:	49 83 3f 00          	cmpq   $0x0,(%r15)
  905f59:	0f 85 89 5a b4 ff    	jne    44b9e8 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x5c>
  905f5f:	90                   	nop
  905f60:	b9 01 00 00 00       	mov    $0x1,%ecx
  905f65:	4c 89 d2             	mov    %r10,%rdx
  905f68:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
  905f6f:	4c 89 8d d0 fe ff ff 	mov    %r9,-0x130(%rbp)
  905f76:	4c 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%r15
  905f7d:	e8 ae 1d b0 ff       	call   407d30 <_ZNKSt8__detail20_Prime_rehash_policy14_M_need_rehashEmmm@plt>
  905f82:	84 c0                	test   %al,%al
  905f84:	4c 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%r9
  905f8b:	74 1e                	je     905fab <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x39b>
  905f8d:	48 89 d6             	mov    %rdx,%rsi
  905f90:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
  905f97:	e8 24 7d ff ff       	call   8fdcc0 <_ZNSt10_HashtableImSt4pairIKmiESaIS2_ENSt8__detail10_Select1stESt8equal_toImESt4hashImENS4_18_Mod_range_hashingENS4_20_Default_ranged_hashENS4_20_Prime_rehash_policyENS4_17_Hashtable_traitsILb0ELb0ELb1EEEE9_M_rehashEmSt17integral_constantIbLb1EE.isra.0>
  905f9c:	48 89 d8             	mov    %rbx,%rax
  905f9f:	31 d2                	xor    %edx,%edx
  905fa1:	48 f7 b5 58 ff ff ff 	divq   -0xa8(%rbp)
  905fa8:	49 89 d1             	mov    %rdx,%r9
  905fab:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
  905fb2:	4a 8d 0c ce          	lea    (%rsi,%r9,8),%rcx
  905fb6:	48 8b 01             	mov    (%rcx),%rax
  905fb9:	48 85 c0             	test   %rax,%rax
  905fbc:	0f 84 f6 02 00 00    	je     9062b8 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x6a8>
  905fc2:	48 8b 00             	mov    (%rax),%rax
  905fc5:	49 89 45 00          	mov    %rax,0x0(%r13)
  905fc9:	48 8b 01             	mov    (%rcx),%rax
  905fcc:	4c 89 28             	mov    %r13,(%rax)
  905fcf:	48 83 85 68 ff ff ff 	addq   $0x1,-0x98(%rbp)
  905fd6:	01 
  905fd7:	49 8d 46 01          	lea    0x1(%r14),%rax
  905fdb:	4c 39 b5 e0 fe ff ff 	cmp    %r14,-0x120(%rbp)
  905fe2:	74 2c                	je     906010 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x400>
  905fe4:	49 89 c6             	mov    %rax,%r14
  905fe7:	e9 3c fe ff ff       	jmp    905e28 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x218>
  905fec:	0f 1f 40 00          	nopl   0x0(%rax)
  905ff0:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  905ff7:	48 89 d8             	mov    %rbx,%rax
  905ffa:	31 d2                	xor    %edx,%edx
  905ffc:	48 f7 f6             	div    %rsi
  905fff:	49 89 d1             	mov    %rdx,%r9
  906002:	e9 59 ff ff ff       	jmp    905f60 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x350>
  906007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  90600e:	00 00 
  906010:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
  906017:	66 0f ef c0          	pxor   %xmm0,%xmm0
  90601b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
  906022:	8b b5 c0 fe ff ff    	mov    -0x140(%rbp),%esi
  906028:	66 48 0f 6e d8       	movq   %rax,%xmm3
  90602d:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  906034:	48 8d 9d 30 ff ff ff 	lea    -0xd0(%rbp),%rbx
  90603b:	0f 11 47 08          	movups %xmm0,0x8(%rdi)
  90603f:	66 48 0f 6e d3       	movq   %rbx,%xmm2
  906044:	0f 11 47 18          	movups %xmm0,0x18(%rdi)
  906048:	48 8b 00             	mov    (%rax),%rax
  90604b:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
  90604f:	0f 29 95 e0 fe ff ff 	movaps %xmm2,-0x120(%rbp)
  906056:	4c 8b 60 08          	mov    0x8(%rax),%r12
  90605a:	4c 2b 20             	sub    (%rax),%r12
  90605d:	0f 11 47 28          	movups %xmm0,0x28(%rdi)
  906061:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
  906068:	49 c1 fc 02          	sar    $0x2,%r12
  90606c:	44 89 e3             	mov    %r12d,%ebx
  90606f:	8b 00                	mov    (%rax),%eax
  906071:	89 37                	mov    %esi,(%rdi)
  906073:	89 85 d0 fe ff ff    	mov    %eax,-0x130(%rbp)
  906079:	44 29 e0             	sub    %r12d,%eax
  90607c:	41 0f af c4          	imul   %r12d,%eax
  906080:	48 63 f0             	movslq %eax,%rsi
  906083:	89 85 0c ff ff ff    	mov    %eax,-0xf4(%rbp)
  906089:	89 47 04             	mov    %eax,0x4(%rdi)
  90608c:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
  906093:	48 0f af f0          	imul   %rax,%rsi
  906097:	48 85 f6             	test   %rsi,%rsi
  90609a:	0f 85 a4 01 00 00    	jne    906244 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x634>
  9060a0:	49 89 c5             	mov    %rax,%r13
  9060a3:	4d 63 fc             	movslq %r12d,%r15
  9060a6:	4d 0f af ef          	imul   %r15,%r13
  9060aa:	4d 85 ed             	test   %r13,%r13
  9060ad:	0f 85 d4 01 00 00    	jne    906287 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x677>
  9060b3:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  9060ba:	4c 89 78 28          	mov    %r15,0x28(%rax)
  9060be:	4c 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%r15
  9060c5:	4c 89 78 30          	mov    %r15,0x30(%rax)
  9060c9:	e8 32 18 b0 ff       	call   407900 <omp_in_parallel@plt>
  9060ce:	85 c0                	test   %eax,%eax
  9060d0:	0f 84 2c 02 00 00    	je     906302 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x6f2>
  9060d6:	ba 01 00 00 00       	mov    $0x1,%edx
  9060db:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
  9060e1:	48 8d 75 90          	lea    -0x70(%rbp),%rsi
  9060e5:	31 c9                	xor    %ecx,%ecx
  9060e7:	44 89 65 c4          	mov    %r12d,-0x3c(%rbp)
  9060eb:	66 0f 6f a5 e0 fe ff 	movdqa -0x120(%rbp),%xmm4
  9060f2:	ff 
  9060f3:	bf 40 de 8f 00       	mov    $0x8fde40,%edi
  9060f8:	89 45 c0             	mov    %eax,-0x40(%rbp)
  9060fb:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
  906102:	0f 11 65 a8          	movups %xmm4,-0x58(%rbp)
  906106:	48 89 45 98          	mov    %rax,-0x68(%rbp)
  90610a:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  906111:	48 89 45 90          	mov    %rax,-0x70(%rbp)
  906115:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  90611c:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
  906120:	48 8d 85 0c ff ff ff 	lea    -0xf4(%rbp),%rax
  906127:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
  90612b:	e8 00 1b b0 ff       	call   407c30 <GOMP_parallel@plt>
  906130:	0f b6 05 c1 08 0a 00 	movzbl 0xa08c1(%rip),%eax        # 9a69f8 <_ZGVZN4xmvb9profiling12phase_totalsEvE6totals>
  906137:	84 c0                	test   %al,%al
  906139:	0f 84 83 03 00 00    	je     9064c2 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x8b2>
  90613f:	80 3d ba 08 0a 00 00 	cmpb   $0x0,0xa08ba(%rip)        # 9a6a00 <_ZZN4xmvb9profiling12phase_totalsEvE6totals>
  906146:	74 3e                	je     906186 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x576>
  906148:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  90614f:	44 8b 85 0c ff ff ff 	mov    -0xf4(%rbp),%r8d
  906156:	89 d9                	mov    %ebx,%ecx
  906158:	48 8b 3d 41 07 0a 00 	mov    0xa0741(%rip),%rdi        # 9a68a0 <stderr@GLIBC_2.2.5>
  90615f:	48 8b 46 28          	mov    0x28(%rsi),%rax
  906163:	48 0f af 46 30       	imul   0x30(%rsi),%rax
  906168:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  90616c:	48 2b 56 08          	sub    0x8(%rsi),%rdx
  906170:	be 08 1f 95 00       	mov    $0x951f08,%esi
  906175:	4c 8d 0c 02          	lea    (%rdx,%rax,1),%r9
  906179:	8b 95 bc fe ff ff    	mov    -0x144(%rbp),%edx
  90617f:	31 c0                	xor    %eax,%eax
  906181:	e8 0a 11 b0 ff       	call   407290 <fprintf@plt>
  906186:	48 8b 9d 60 ff ff ff 	mov    -0xa0(%rbp),%rbx
  90618d:	48 85 db             	test   %rbx,%rbx
  906190:	74 1b                	je     9061ad <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x59d>
  906192:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  906198:	48 89 df             	mov    %rbx,%rdi
  90619b:	48 8b 1b             	mov    (%rbx),%rbx
  90619e:	be 18 00 00 00       	mov    $0x18,%esi
  9061a3:	e8 b8 0f b0 ff       	call   407160 <_ZdlPvm@plt>
  9061a8:	48 85 db             	test   %rbx,%rbx
  9061ab:	75 eb                	jne    906198 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x588>
  9061ad:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
  9061b4:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  9061bb:	31 f6                	xor    %esi,%esi
  9061bd:	48 8d 5d 80          	lea    -0x80(%rbp),%rbx
  9061c1:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
  9061c8:	00 
  9061c9:	e8 d2 11 b0 ff       	call   4073a0 <memset@plt>
  9061ce:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  9061d5:	48 c7 85 68 ff ff ff 	movq   $0x0,-0x98(%rbp)
  9061dc:	00 00 00 00 
  9061e0:	48 c7 85 60 ff ff ff 	movq   $0x0,-0xa0(%rbp)
  9061e7:	00 00 00 00 
  9061eb:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
  9061f2:	48 39 df             	cmp    %rbx,%rdi
  9061f5:	74 0d                	je     906204 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x5f4>
  9061f7:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
  9061fe:	00 
  9061ff:	e8 5c 0f b0 ff       	call   407160 <_ZdlPvm@plt>
  906204:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
  90620b:	48 85 ff             	test   %rdi,%rdi
  90620e:	74 0f                	je     90621f <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x60f>
  906210:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
  906217:	48 29 fe             	sub    %rdi,%rsi
  90621a:	e8 41 0f b0 ff       	call   407160 <_ZdlPvm@plt>
  90621f:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
  906226:	e8 55 8f bc ff       	call   4cf180 <_ZN4xmvb9profiling11ScopedPhase4stopEv>
  90622b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  906232:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
  906239:	5b                   	pop    %rbx
  90623a:	41 5c                	pop    %r12
  90623c:	41 5d                	pop    %r13
  90623e:	41 5e                	pop    %r14
  906240:	41 5f                	pop    %r15
  906242:	5d                   	pop    %rbp
  906243:	c3                   	ret    
  906244:	49 89 fe             	mov    %rdi,%r14
  906247:	48 8d 7f 08          	lea    0x8(%rdi),%rdi
  90624b:	e8 f0 f7 ff ff       	call   905a40 <_ZNSt6vectorIN4xmvb5mcscf8SpinLinkESaIS2_EE17_M_default_appendEm>
  906250:	4c 8b ad c8 fe ff ff 	mov    -0x138(%rbp),%r13
  906257:	4d 63 fc             	movslq %r12d,%r15
  90625a:	49 8b 46 28          	mov    0x28(%r14),%rax
  90625e:	49 0f af 46 30       	imul   0x30(%r14),%rax
  906263:	4d 0f af ef          	imul   %r15,%r13
  906267:	49 39 c5             	cmp    %rax,%r13
  90626a:	0f 84 43 fe ff ff    	je     9060b3 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x4a3>
  906270:	49 8b 7e 20          	mov    0x20(%r14),%rdi
  906274:	48 85 ff             	test   %rdi,%rdi
  906277:	74 05                	je     90627e <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x66e>
  906279:	e8 c2 0f b0 ff       	call   407240 <free@plt>
  90627e:	4d 85 ed             	test   %r13,%r13
  906281:	0f 84 6e 03 00 00    	je     9065f5 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x9e5>
  906287:	4d 85 ed             	test   %r13,%r13
  90628a:	0f 88 53 57 b4 ff    	js     44b9e3 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x57>
  906290:	4c 89 ef             	mov    %r13,%rdi
  906293:	e8 38 19 b0 ff       	call   407bd0 <malloc@plt>
  906298:	48 85 c0             	test   %rax,%rax
  90629b:	0f 84 f5 56 b4 ff    	je     44b996 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xa>
  9062a1:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  9062a8:	48 89 46 20          	mov    %rax,0x20(%rsi)
  9062ac:	e9 02 fe ff ff       	jmp    9060b3 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x4a3>
  9062b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  9062b8:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
  9062bf:	4c 89 ad 60 ff ff ff 	mov    %r13,-0xa0(%rbp)
  9062c6:	49 89 45 00          	mov    %rax,0x0(%r13)
  9062ca:	48 85 c0             	test   %rax,%rax
  9062cd:	74 11                	je     9062e0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x6d0>
  9062cf:	48 8b 40 08          	mov    0x8(%rax),%rax
  9062d3:	31 d2                	xor    %edx,%edx
  9062d5:	48 f7 b5 58 ff ff ff 	divq   -0xa8(%rbp)
  9062dc:	4c 89 2c d6          	mov    %r13,(%rsi,%rdx,8)
  9062e0:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
  9062e7:	48 89 01             	mov    %rax,(%rcx)
  9062ea:	e9 e0 fc ff ff       	jmp    905fcf <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x3bf>
  9062ef:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  9062f3:	f2 48 0f 2c f0       	cvttsd2si %xmm0,%rsi
  9062f8:	48 0f ba fe 3f       	btc    $0x3f,%rsi
  9062fd:	e9 d0 fa ff ff       	jmp    905dd2 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x1c2>
  906302:	e8 39 11 b0 ff       	call   407440 <omp_get_max_threads@plt>
  906307:	4d 85 ff             	test   %r15,%r15
  90630a:	0f 84 c6 fd ff ff    	je     9060d6 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x4c6>
  906310:	85 c0                	test   %eax,%eax
  906312:	ba 01 00 00 00       	mov    $0x1,%edx
  906317:	0f 4e c2             	cmovle %edx,%eax
  90631a:	48 63 d0             	movslq %eax,%rdx
  90631d:	4c 89 f8             	mov    %r15,%rax
  906320:	4c 39 fa             	cmp    %r15,%rdx
  906323:	48 89 d1             	mov    %rdx,%rcx
  906326:	49 0f 47 cf          	cmova  %r15,%rcx
  90632a:	31 d2                	xor    %edx,%edx
  90632c:	48 f7 f1             	div    %rcx
  90632f:	89 ca                	mov    %ecx,%edx
  906331:	48 39 c8             	cmp    %rcx,%rax
  906334:	0f 83 a1 fd ff ff    	jae    9060db <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x4cb>
  90633a:	e9 97 fd ff ff       	jmp    9060d6 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x4c6>
  90633f:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
  906346:	48 89 c6             	mov    %rax,%rsi
  906349:	e8 72 79 ff ff       	call   8fdcc0 <_ZNSt10_HashtableImSt4pairIKmiESaIS2_ENSt8__detail10_Select1stESt8equal_toImESt4hashImENS4_18_Mod_range_hashingENS4_20_Default_ranged_hashENS4_20_Prime_rehash_policyENS4_17_Hashtable_traitsILb0ELb0ELb1EEEE9_M_rehashEmSt17integral_constantIbLb1EE.isra.0>
  90634e:	e9 af fa ff ff       	jmp    905e02 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x1f2>
  906353:	48 c7 85 30 ff ff ff 	movq   $0x0,-0xd0(%rbp)
  90635a:	00 00 00 00 
  90635e:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
  906365:	31 ff                	xor    %edi,%edi
  906367:	48 c7 85 40 ff ff ff 	movq   $0x0,-0xc0(%rbp)
  90636e:	00 00 00 00 
  906372:	e9 e2 f9 ff ff       	jmp    905d59 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x149>
  906377:	48 89 d8             	mov    %rbx,%rax
  90637a:	83 e3 01             	and    $0x1,%ebx
  90637d:	66 0f ef c0          	pxor   %xmm0,%xmm0
  906381:	48 d1 e8             	shr    %rax
  906384:	48 09 d8             	or     %rbx,%rax
  906387:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
  90638c:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
  906390:	e9 26 fa ff ff       	jmp    905dbb <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x1ab>
  906395:	bf f8 69 9a 00       	mov    $0x9a69f8,%edi
  90639a:	e8 91 10 b0 ff       	call   407430 <__cxa_guard_acquire@plt>
  90639f:	85 c0                	test   %eax,%eax
  9063a1:	0f 84 ab f8 ff ff    	je     905c52 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x42>
  9063a7:	ba 10 6a 9a 00       	mov    $0x9a6a10,%edx
  9063ac:	31 c0                	xor    %eax,%eax
  9063ae:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063b3:	48 c7 05 42 06 0a 00 	movq   $0x0,0xa0642(%rip)        # 9a6a00 <_ZZN4xmvb9profiling12phase_totalsEvE6totals>
  9063ba:	00 00 00 00 
  9063be:	48 c7 05 3f 06 0a 00 	movq   $0x0,0xa063f(%rip)        # 9a6a08 <_ZZN4xmvb9profiling12phase_totalsEvE6totals+0x8>
  9063c5:	00 00 00 00 
  9063c9:	48 89 d7             	mov    %rdx,%rdi
  9063cc:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063cf:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063d4:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063d7:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063dc:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063df:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063e4:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063e7:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063ec:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063ef:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063f4:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063f7:	b9 47 00 00 00       	mov    $0x47,%ecx
  9063fc:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9063ff:	b9 47 00 00 00       	mov    $0x47,%ecx
  906404:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906407:	b9 47 00 00 00       	mov    $0x47,%ecx
  90640c:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90640f:	b9 47 00 00 00       	mov    $0x47,%ecx
  906414:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906417:	b9 47 00 00 00       	mov    $0x47,%ecx
  90641c:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90641f:	b9 47 00 00 00       	mov    $0x47,%ecx
  906424:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906427:	b9 47 00 00 00       	mov    $0x47,%ecx
  90642c:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90642f:	b9 47 00 00 00       	mov    $0x47,%ecx
  906434:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906437:	b9 47 00 00 00       	mov    $0x47,%ecx
  90643c:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90643f:	bf 73 8a 93 00       	mov    $0x938a73,%edi
  906444:	e8 27 15 b0 ff       	call   407970 <getenv@plt>
  906449:	31 d2                	xor    %edx,%edx
  90644b:	48 85 c0             	test   %rax,%rax
  90644e:	74 06                	je     906456 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x846>
  906450:	80 38 31             	cmpb   $0x31,(%rax)
  906453:	0f 94 c2             	sete   %dl
  906456:	88 15 a4 05 0a 00    	mov    %dl,0xa05a4(%rip)        # 9a6a00 <_ZZN4xmvb9profiling12phase_totalsEvE6totals>
  90645c:	b8 f0 72 9a 00       	mov    $0x9a72f0,%eax
  906461:	b9 28 75 9a 00       	mov    $0x9a7528,%ecx
  906466:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  90646d:	0f 1f 00             	nopl   (%rax)
  906470:	48 89 d3             	mov    %rdx,%rbx
  906473:	48 87 18             	xchg   %rbx,(%rax)
  906476:	48 83 c0 08          	add    $0x8,%rax
  90647a:	48 39 c1             	cmp    %rax,%rcx
  90647d:	75 f1                	jne    906470 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x860>
  90647f:	b8 60 77 9a 00       	mov    $0x9a7760,%eax
  906484:	b9 98 79 9a 00       	mov    $0x9a7998,%ecx
  906489:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  906490:	48 89 d6             	mov    %rdx,%rsi
  906493:	48 87 30             	xchg   %rsi,(%rax)
  906496:	48 83 c0 08          	add    $0x8,%rax
  90649a:	48 39 c1             	cmp    %rax,%rcx
  90649d:	75 f1                	jne    906490 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x880>
  90649f:	ba 78 67 9a 00       	mov    $0x9a6778,%edx
  9064a4:	be 00 6a 9a 00       	mov    $0x9a6a00,%esi
  9064a9:	bf 40 e9 4c 00       	mov    $0x4ce940,%edi
  9064ae:	e8 8d 16 b0 ff       	call   407b40 <__cxa_atexit@plt>
  9064b3:	bf f8 69 9a 00       	mov    $0x9a69f8,%edi
  9064b8:	e8 53 12 b0 ff       	call   407710 <__cxa_guard_release@plt>
  9064bd:	e9 90 f7 ff ff       	jmp    905c52 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x42>
  9064c2:	bf f8 69 9a 00       	mov    $0x9a69f8,%edi
  9064c7:	e8 64 0f b0 ff       	call   407430 <__cxa_guard_acquire@plt>
  9064cc:	85 c0                	test   %eax,%eax
  9064ce:	0f 84 6b fc ff ff    	je     90613f <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x52f>
  9064d4:	ba 10 6a 9a 00       	mov    $0x9a6a10,%edx
  9064d9:	31 c0                	xor    %eax,%eax
  9064db:	b9 47 00 00 00       	mov    $0x47,%ecx
  9064e0:	48 c7 05 15 05 0a 00 	movq   $0x0,0xa0515(%rip)        # 9a6a00 <_ZZN4xmvb9profiling12phase_totalsEvE6totals>
  9064e7:	00 00 00 00 
  9064eb:	48 c7 05 12 05 0a 00 	movq   $0x0,0xa0512(%rip)        # 9a6a08 <_ZZN4xmvb9profiling12phase_totalsEvE6totals+0x8>
  9064f2:	00 00 00 00 
  9064f6:	48 89 d7             	mov    %rdx,%rdi
  9064f9:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  9064fc:	b9 47 00 00 00       	mov    $0x47,%ecx
  906501:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906504:	b9 47 00 00 00       	mov    $0x47,%ecx
  906509:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90650c:	b9 47 00 00 00       	mov    $0x47,%ecx
  906511:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906514:	b9 47 00 00 00       	mov    $0x47,%ecx
  906519:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90651c:	b9 47 00 00 00       	mov    $0x47,%ecx
  906521:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906524:	b9 47 00 00 00       	mov    $0x47,%ecx
  906529:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90652c:	b9 47 00 00 00       	mov    $0x47,%ecx
  906531:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906534:	b9 47 00 00 00       	mov    $0x47,%ecx
  906539:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90653c:	b9 47 00 00 00       	mov    $0x47,%ecx
  906541:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906544:	b9 47 00 00 00       	mov    $0x47,%ecx
  906549:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90654c:	b9 47 00 00 00       	mov    $0x47,%ecx
  906551:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906554:	b9 47 00 00 00       	mov    $0x47,%ecx
  906559:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90655c:	b9 47 00 00 00       	mov    $0x47,%ecx
  906561:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  906564:	b9 47 00 00 00       	mov    $0x47,%ecx
  906569:	f3 48 ab             	rep stos %rax,%es:(%rdi)
  90656c:	bf 73 8a 93 00       	mov    $0x938a73,%edi
  906571:	e8 fa 13 b0 ff       	call   407970 <getenv@plt>
  906576:	31 d2                	xor    %edx,%edx
  906578:	48 85 c0             	test   %rax,%rax
  90657b:	74 06                	je     906583 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x973>
  90657d:	80 38 31             	cmpb   $0x31,(%rax)
  906580:	0f 94 c2             	sete   %dl
  906583:	88 15 77 04 0a 00    	mov    %dl,0xa0477(%rip)        # 9a6a00 <_ZZN4xmvb9profiling12phase_totalsEvE6totals>
  906589:	b8 f0 72 9a 00       	mov    $0x9a72f0,%eax
  90658e:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  906595:	0f 1f 00             	nopl   (%rax)
  906598:	48 89 d6             	mov    %rdx,%rsi
  90659b:	48 87 30             	xchg   %rsi,(%rax)
  90659e:	48 83 c0 08          	add    $0x8,%rax
  9065a2:	48 3d 28 75 9a 00    	cmp    $0x9a7528,%rax
  9065a8:	75 ee                	jne    906598 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x988>
  9065aa:	b8 60 77 9a 00       	mov    $0x9a7760,%eax
  9065af:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  9065b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  9065bd:	00 00 00 
  9065c0:	48 89 d6             	mov    %rdx,%rsi
  9065c3:	48 87 30             	xchg   %rsi,(%rax)
  9065c6:	48 83 c0 08          	add    $0x8,%rax
  9065ca:	48 3d 98 79 9a 00    	cmp    $0x9a7998,%rax
  9065d0:	75 ee                	jne    9065c0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x9b0>
  9065d2:	ba 78 67 9a 00       	mov    $0x9a6778,%edx
  9065d7:	be 00 6a 9a 00       	mov    $0x9a6a00,%esi
  9065dc:	bf 40 e9 4c 00       	mov    $0x4ce940,%edi
  9065e1:	e8 5a 15 b0 ff       	call   407b40 <__cxa_atexit@plt>
  9065e6:	bf f8 69 9a 00       	mov    $0x9a69f8,%edi
  9065eb:	e8 20 11 b0 ff       	call   407710 <__cxa_guard_release@plt>
  9065f0:	e9 4a fb ff ff       	jmp    90613f <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x52f>
  9065f5:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  9065fc:	31 c0                	xor    %eax,%eax
  9065fe:	48 89 46 20          	mov    %rax,0x20(%rsi)
  906602:	e9 ac fa ff ff       	jmp    9060b3 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE+0x4a3>
  906607:	e9 8f 53 b4 ff       	jmp    44b99b <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xf>
  90660c:	48 89 c3             	mov    %rax,%rbx
  90660f:	e9 0d 54 b4 ff       	jmp    44ba21 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x95>
  906614:	e9 1e 54 b4 ff       	jmp    44ba37 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xab>
  906619:	e9 94 53 b4 ff       	jmp    44b9b2 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x26>
  90661e:	48 89 c3             	mov    %rax,%rbx
  906621:	e9 c8 54 b4 ff       	jmp    44baee <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x162>

Disassembly of section .fini:

build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000008fde40 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0>:
  8fde40:	55                   	push   %rbp
  8fde41:	48 89 e5             	mov    %rsp,%rbp
  8fde44:	41 57                	push   %r15
  8fde46:	41 56                	push   %r14
  8fde48:	41 55                	push   %r13
  8fde4a:	41 54                	push   %r12
  8fde4c:	53                   	push   %rbx
  8fde4d:	48 89 fb             	mov    %rdi,%rbx
  8fde50:	48 81 ec 88 01 00 00 	sub    $0x188,%rsp
  8fde57:	e8 c4 96 b0 ff       	call   407520 <omp_get_num_threads@plt>
  8fde5c:	41 89 c4             	mov    %eax,%r12d
  8fde5f:	e8 2c 97 b0 ff       	call   407590 <omp_get_thread_num@plt>
  8fde64:	89 c1                	mov    %eax,%ecx
  8fde66:	8b 43 30             	mov    0x30(%rbx),%eax
  8fde69:	99                   	cltd   
  8fde6a:	41 f7 fc             	idiv   %r12d
  8fde6d:	39 d1                	cmp    %edx,%ecx
  8fde6f:	0f 8c 2d 04 00 00    	jl     8fe2a2 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x462>
  8fde75:	0f af c8             	imul   %eax,%ecx
  8fde78:	01 ca                	add    %ecx,%edx
  8fde7a:	44 8d 14 10          	lea    (%rax,%rdx,1),%r10d
  8fde7e:	44 39 d2             	cmp    %r10d,%edx
  8fde81:	0f 8d 09 04 00 00    	jge    8fe290 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x450>
  8fde87:	48 63 c2             	movslq %edx,%rax
  8fde8a:	8b 7b 34             	mov    0x34(%rbx),%edi
  8fde8d:	4c 8b 5b 08          	mov    0x8(%rbx),%r11
  8fde91:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
  8fde98:	41 89 f9             	mov    %edi,%r9d
  8fde9b:	4c 89 df             	mov    %r11,%rdi
  8fde9e:	45 89 d3             	mov    %r10d,%r11d
  8fdea1:	48 8b 13             	mov    (%rbx),%rdx
  8fdea4:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  8fdeab:	48 8b 12             	mov    (%rdx),%rdx
  8fdeae:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  8fdeb2:	4c 8d 24 c2          	lea    (%rdx,%rax,8),%r12
  8fdeb6:	45 85 c9             	test   %r9d,%r9d
  8fdeb9:	7e 39                	jle    8fdef4 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0xb4>
  8fdebb:	48 8b 53 10          	mov    0x10(%rbx),%rdx
  8fdebf:	4c 8b ad 88 fe ff ff 	mov    -0x178(%rbp),%r13
  8fdec6:	4d 63 d1             	movslq %r9d,%r10
  8fdec9:	31 c0                	xor    %eax,%eax
  8fdecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  8fded0:	48 8b 4a 28          	mov    0x28(%rdx),%rcx
  8fded4:	4d 8b 04 24          	mov    (%r12),%r8
  8fded8:	48 8b 72 20          	mov    0x20(%rdx),%rsi
  8fdedc:	49 0f af cd          	imul   %r13,%rcx
  8fdee0:	45 8b 04 80          	mov    (%r8,%rax,4),%r8d
  8fdee4:	48 01 c6             	add    %rax,%rsi
  8fdee7:	48 83 c0 01          	add    $0x1,%rax
  8fdeeb:	44 88 04 0e          	mov    %r8b,(%rsi,%rcx,1)
  8fdeef:	4c 39 d0             	cmp    %r10,%rax
  8fdef2:	75 dc                	jne    8fded0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x90>
  8fdef4:	8b 37                	mov    (%rdi),%esi
  8fdef6:	85 f6                	test   %esi,%esi
  8fdef8:	0f 8e 7a 03 00 00    	jle    8fe278 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x438>
  8fdefe:	48 8b 95 88 fe ff ff 	mov    -0x178(%rbp),%rdx
  8fdf05:	4c 8b 7b 18          	mov    0x18(%rbx),%r15
  8fdf09:	31 c9                	xor    %ecx,%ecx
  8fdf0b:	48 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%rax
  8fdf12:	00 
  8fdf13:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
  8fdf1a:	49 8b 07             	mov    (%r15),%rax
  8fdf1d:	48 8b 04 d0          	mov    (%rax,%rdx,8),%rax
  8fdf21:	31 d2                	xor    %edx,%edx
  8fdf23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  8fdf28:	48 0f a3 d0          	bt     %rdx,%rax
  8fdf2c:	72 0e                	jb     8fdf3c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0xfc>
  8fdf2e:	4c 63 c1             	movslq %ecx,%r8
  8fdf31:	83 c1 01             	add    $0x1,%ecx
  8fdf34:	42 89 94 85 d0 fe ff 	mov    %edx,-0x130(%rbp,%r8,4)
  8fdf3b:	ff 
  8fdf3c:	83 c2 01             	add    $0x1,%edx
  8fdf3f:	39 d6                	cmp    %edx,%esi
  8fdf41:	75 e5                	jne    8fdf28 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0xe8>
  8fdf43:	48 8b 53 10          	mov    0x10(%rbx),%rdx
  8fdf47:	4c 8b 73 20          	mov    0x20(%rbx),%r14
  8fdf4b:	48 89 bd 70 fe ff ff 	mov    %rdi,-0x190(%rbp)
  8fdf52:	45 31 ed             	xor    %r13d,%r13d
  8fdf55:	44 89 9d 58 fe ff ff 	mov    %r11d,-0x1a8(%rbp)
  8fdf5c:	48 89 95 80 fe ff ff 	mov    %rdx,-0x180(%rbp)
  8fdf63:	48 8b 53 28          	mov    0x28(%rbx),%rdx
  8fdf67:	4c 89 a5 60 fe ff ff 	mov    %r12,-0x1a0(%rbp)
  8fdf6e:	48 89 95 78 fe ff ff 	mov    %rdx,-0x188(%rbp)
  8fdf75:	89 8d 5c fe ff ff    	mov    %ecx,-0x1a4(%rbp)
  8fdf7b:	44 89 8d 90 fe ff ff 	mov    %r9d,-0x170(%rbp)
  8fdf82:	4d 89 f9             	mov    %r15,%r9
  8fdf85:	48 89 9d 68 fe ff ff 	mov    %rbx,-0x198(%rbp)
  8fdf8c:	4c 89 f3             	mov    %r14,%rbx
  8fdf8f:	45 89 ee             	mov    %r13d,%r14d
  8fdf92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  8fdf98:	44 89 f1             	mov    %r14d,%ecx
  8fdf9b:	48 d3 e8             	shr    %cl,%rax
  8fdf9e:	83 e0 01             	and    $0x1,%eax
  8fdfa1:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
  8fdfa8:	0f 84 72 02 00 00    	je     8fe220 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3e0>
  8fdfae:	48 63 85 5c fe ff ff 	movslq -0x1a4(%rbp),%rax
  8fdfb5:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
  8fdfbc:	85 c0                	test   %eax,%eax
  8fdfbe:	0f 8e b2 01 00 00    	jle    8fe176 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x336>
  8fdfc4:	4d 63 ed             	movslq %r13d,%r13
  8fdfc7:	49 89 d8             	mov    %rbx,%r8
  8fdfca:	4c 01 e8             	add    %r13,%rax
  8fdfcd:	4c 89 eb             	mov    %r13,%rbx
  8fdfd0:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
  8fdfd7:	4c 89 e8             	mov    %r13,%rax
  8fdfda:	48 f7 d8             	neg    %rax
  8fdfdd:	48 8d 04 82          	lea    (%rdx,%rax,4),%rax
  8fdfe1:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
  8fdfe8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  8fdfef:	00 
  8fdff0:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  8fdff7:	89 9d 94 fe ff ff    	mov    %ebx,-0x16c(%rbp)
  8fdffd:	44 8b 3c 98          	mov    (%rax,%rbx,4),%r15d
  8fe001:	45 39 f7             	cmp    %r14d,%r15d
  8fe004:	0f 8d 36 02 00 00    	jge    8fe240 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x400>
  8fe00a:	48 83 bd a8 fe ff ff 	cmpq   $0x0,-0x158(%rbp)
  8fe011:	00 
  8fe012:	45 89 f5             	mov    %r14d,%r13d
  8fe015:	75 06                	jne    8fe01d <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x1dd>
  8fe017:	45 89 fd             	mov    %r15d,%r13d
  8fe01a:	45 89 f7             	mov    %r14d,%r15d
  8fe01d:	49 8b 01             	mov    (%r9),%rax
  8fe020:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
  8fe027:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  8fe02d:	44 89 e9             	mov    %r13d,%ecx
  8fe030:	49 d3 e4             	shl    %cl,%r12
  8fe033:	4d 0f bb fc          	btc    %r15,%r12
  8fe037:	4c 33 24 38          	xor    (%rax,%rdi,1),%r12
  8fe03b:	49 83 78 18 00       	cmpq   $0x0,0x18(%r8)
  8fe040:	0f 85 62 01 00 00    	jne    8fe1a8 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x368>
  8fe046:	49 8b 40 10          	mov    0x10(%r8),%rax
  8fe04a:	48 85 c0             	test   %rax,%rax
  8fe04d:	75 15                	jne    8fe064 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x224>
  8fe04f:	e9 ab 01 00 00       	jmp    8fe1ff <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3bf>
  8fe054:	0f 1f 40 00          	nopl   0x0(%rax)
  8fe058:	48 8b 00             	mov    (%rax),%rax
  8fe05b:	48 85 c0             	test   %rax,%rax
  8fe05e:	0f 84 9b 01 00 00    	je     8fe1ff <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3bf>
  8fe064:	4c 3b 60 08          	cmp    0x8(%rax),%r12
  8fe068:	75 ee                	jne    8fe058 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x218>
  8fe06a:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
  8fe071:	8b 40 10             	mov    0x10(%rax),%eax
  8fe074:	44 89 ee             	mov    %r13d,%esi
  8fe077:	4c 89 8d b8 fe ff ff 	mov    %r9,-0x148(%rbp)
  8fe07e:	4c 89 85 c0 fe ff ff 	mov    %r8,-0x140(%rbp)
  8fe085:	48 63 17             	movslq (%rdi),%rdx
  8fe088:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
  8fe08f:	48 0f af d7          	imul   %rdi,%rdx
  8fe093:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
  8fe09a:	48 01 da             	add    %rbx,%rdx
  8fe09d:	48 c1 e2 04          	shl    $0x4,%rdx
  8fe0a1:	48 03 57 08          	add    0x8(%rdi),%rdx
  8fe0a5:	44 89 ff             	mov    %r15d,%edi
  8fe0a8:	89 02                	mov    %eax,(%rdx)
  8fe0aa:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
  8fe0b1:	e8 9a f2 ff ff       	call   8fd350 <_ZN4xmvb4core9PairIndex17packed_pair_indexEii>
  8fe0b6:	45 39 ef             	cmp    %r13d,%r15d
  8fe0b9:	44 89 ee             	mov    %r13d,%esi
  8fe0bc:	44 89 e9             	mov    %r13d,%ecx
  8fe0bf:	41 0f 4d f7          	cmovge %r15d,%esi
  8fe0c3:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
  8fe0ca:	41 0f 4e cf          	cmovle %r15d,%ecx
  8fe0ce:	f2 0f 10 05 a2 31 03 	movsd  0x331a2(%rip),%xmm0        # 931278 <_ZTVSt23_Sp_counted_ptr_inplaceIKN4xmvb2vb25LibcintRiIntegralProviderESaIvELN9__gnu_cxx12_Lock_policyE2EE+0x38>
  8fe0d5:	00 
  8fe0d6:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
  8fe0dd:	4c 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%r9
  8fe0e4:	66 89 42 04          	mov    %ax,0x4(%rdx)
  8fe0e8:	89 f0                	mov    %esi,%eax
  8fe0ea:	29 c8                	sub    %ecx,%eax
  8fe0ec:	83 f8 01             	cmp    $0x1,%eax
  8fe0ef:	7e 4d                	jle    8fe13e <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x2fe>
  8fe0f1:	83 c1 01             	add    $0x1,%ecx
  8fe0f4:	b8 01 00 00 00       	mov    $0x1,%eax
  8fe0f9:	bf 01 00 00 00       	mov    $0x1,%edi
  8fe0fe:	48 d3 e0             	shl    %cl,%rax
  8fe101:	89 f1                	mov    %esi,%ecx
  8fe103:	66 48 0f 7e c6       	movq   %xmm0,%rsi
  8fe108:	48 d3 e7             	shl    %cl,%rdi
  8fe10b:	48 83 e8 01          	sub    $0x1,%rax
  8fe10f:	48 89 f9             	mov    %rdi,%rcx
  8fe112:	48 83 e9 01          	sub    $0x1,%rcx
  8fe116:	48 31 c8             	xor    %rcx,%rax
  8fe119:	4c 21 e0             	and    %r12,%rax
  8fe11c:	48 89 c1             	mov    %rax,%rcx
  8fe11f:	48 c1 e9 20          	shr    $0x20,%rcx
  8fe123:	31 c8                	xor    %ecx,%eax
  8fe125:	89 c1                	mov    %eax,%ecx
  8fe127:	c1 e9 10             	shr    $0x10,%ecx
  8fe12a:	31 c8                	xor    %ecx,%eax
  8fe12c:	30 e0                	xor    %ah,%al
  8fe12e:	48 8b 05 fb 97 03 00 	mov    0x397fb(%rip),%rax        # 937930 <_ZN4xmvb6output12_GLOBAL__N_1L15kElementSymbolsE+0x2ab0>
  8fe135:	48 0f 4a c6          	cmovp  %rsi,%rax
  8fe139:	66 48 0f 6e c0       	movq   %rax,%xmm0
  8fe13e:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  8fe145:	48 83 c3 01          	add    $0x1,%rbx
  8fe149:	44 88 6a 06          	mov    %r13b,0x6(%rdx)
  8fe14d:	44 88 7a 07          	mov    %r15b,0x7(%rdx)
  8fe151:	f2 0f 11 42 08       	movsd  %xmm0,0x8(%rdx)
  8fe156:	48 39 c3             	cmp    %rax,%rbx
  8fe159:	0f 85 91 fe ff ff    	jne    8fdff0 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x1b0>
  8fe15f:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  8fe166:	44 8b ad 94 fe ff ff 	mov    -0x16c(%rbp),%r13d
  8fe16d:	4c 89 c3             	mov    %r8,%rbx
  8fe170:	8b 30                	mov    (%rax),%esi
  8fe172:	41 83 c5 01          	add    $0x1,%r13d
  8fe176:	41 83 c6 01          	add    $0x1,%r14d
  8fe17a:	41 39 f6             	cmp    %esi,%r14d
  8fe17d:	0f 8d d9 00 00 00    	jge    8fe25c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x41c>
  8fe183:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
  8fe18a:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
  8fe191:	48 8b 40 18          	mov    0x18(%rax),%rax
  8fe195:	48 8b 00             	mov    (%rax),%rax
  8fe198:	48 8b 04 38          	mov    (%rax,%rdi,1),%rax
  8fe19c:	e9 f7 fd ff ff       	jmp    8fdf98 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x158>
  8fe1a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  8fe1a8:	49 8b 78 08          	mov    0x8(%r8),%rdi
  8fe1ac:	4c 89 e0             	mov    %r12,%rax
  8fe1af:	31 d2                	xor    %edx,%edx
  8fe1b1:	48 f7 f7             	div    %rdi
  8fe1b4:	49 8b 00             	mov    (%r8),%rax
  8fe1b7:	4c 8b 1c d0          	mov    (%rax,%rdx,8),%r11
  8fe1bb:	49 89 d2             	mov    %rdx,%r10
  8fe1be:	4d 85 db             	test   %r11,%r11
  8fe1c1:	74 3c                	je     8fe1ff <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3bf>
  8fe1c3:	49 8b 03             	mov    (%r11),%rax
  8fe1c6:	48 8b 48 08          	mov    0x8(%rax),%rcx
  8fe1ca:	49 39 cc             	cmp    %rcx,%r12
  8fe1cd:	74 24                	je     8fe1f3 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3b3>
  8fe1cf:	48 8b 30             	mov    (%rax),%rsi
  8fe1d2:	48 85 f6             	test   %rsi,%rsi
  8fe1d5:	74 28                	je     8fe1ff <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3bf>
  8fe1d7:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  8fe1db:	49 89 c3             	mov    %rax,%r11
  8fe1de:	31 d2                	xor    %edx,%edx
  8fe1e0:	48 89 c8             	mov    %rcx,%rax
  8fe1e3:	48 f7 f7             	div    %rdi
  8fe1e6:	49 39 d2             	cmp    %rdx,%r10
  8fe1e9:	75 14                	jne    8fe1ff <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x3bf>
  8fe1eb:	48 89 f0             	mov    %rsi,%rax
  8fe1ee:	49 39 cc             	cmp    %rcx,%r12
  8fe1f1:	75 dc                	jne    8fe1cf <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x38f>
  8fe1f3:	49 8b 03             	mov    (%r11),%rax
  8fe1f6:	48 85 c0             	test   %rax,%rax
  8fe1f9:	0f 85 6b fe ff ff    	jne    8fe06a <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x22a>
  8fe1ff:	bf 10 00 00 00       	mov    $0x10,%edi
  8fe204:	e8 d7 92 b0 ff       	call   4074e0 <__cxa_allocate_exception@plt>
  8fe209:	be f0 1b 95 00       	mov    $0x951bf0,%esi
  8fe20e:	48 89 c7             	mov    %rax,%rdi
  8fe211:	48 89 c3             	mov    %rax,%rbx
  8fe214:	e8 87 98 b0 ff       	call   407aa0 <_ZNSt11logic_errorC1EPKc@plt>
  8fe219:	e9 f2 d0 b4 ff       	jmp    44b310 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0.cold>
  8fe21e:	66 90                	xchg   %ax,%ax
  8fe220:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  8fe227:	48 8b 10             	mov    (%rax),%rdx
  8fe22a:	48 63 85 90 fe ff ff 	movslq -0x170(%rbp),%rax
  8fe231:	e9 86 fd ff ff       	jmp    8fdfbc <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x17c>
  8fe236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  8fe23d:	00 00 00 
  8fe240:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  8fe247:	41 83 c6 01          	add    $0x1,%r14d
  8fe24b:	49 89 dd             	mov    %rbx,%r13
  8fe24e:	4c 89 c3             	mov    %r8,%rbx
  8fe251:	8b 30                	mov    (%rax),%esi
  8fe253:	41 39 f6             	cmp    %esi,%r14d
  8fe256:	0f 8c 27 ff ff ff    	jl     8fe183 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x343>
  8fe25c:	44 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%r9d
  8fe263:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
  8fe26a:	44 8b 9d 58 fe ff ff 	mov    -0x1a8(%rbp),%r11d
  8fe271:	48 8b 9d 68 fe ff ff 	mov    -0x198(%rbp),%rbx
  8fe278:	48 83 85 88 fe ff ff 	addq   $0x1,-0x178(%rbp)
  8fe27f:	01 
  8fe280:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  8fe287:	41 39 c3             	cmp    %eax,%r11d
  8fe28a:	0f 8f 11 fc ff ff    	jg     8fdea1 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x61>
  8fe290:	48 81 c4 88 01 00 00 	add    $0x188,%rsp
  8fe297:	5b                   	pop    %rbx
  8fe298:	41 5c                	pop    %r12
  8fe29a:	41 5d                	pop    %r13
  8fe29c:	41 5e                	pop    %r14
  8fe29e:	41 5f                	pop    %r15
  8fe2a0:	5d                   	pop    %rbp
  8fe2a1:	c3                   	ret    
  8fe2a2:	83 c0 01             	add    $0x1,%eax
  8fe2a5:	31 d2                	xor    %edx,%edx
  8fe2a7:	e9 c9 fb ff ff       	jmp    8fde75 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0+0x35>
  8fe2ac:	49 89 c4             	mov    %rax,%r12
  8fe2af:	e9 6e d0 b4 ff       	jmp    44b322 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0.cold+0x12>

Disassembly of section .fini:

build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000044b310 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE._omp_fn.0.cold>:
  44b310:	ba 80 7d 40 00       	mov    $0x407d80,%edx
  44b315:	be 60 5d 9a 00       	mov    $0x9a5d60,%esi
  44b31a:	48 89 df             	mov    %rbx,%rdi
  44b31d:	e8 ce c4 fb ff       	call   4077f0 <__cxa_throw@plt>
  44b322:	48 89 df             	mov    %rbx,%rdi
  44b325:	e8 36 c8 fb ff       	call   407b60 <__cxa_free_exception@plt>
  44b32a:	4c 89 e7             	mov    %r12,%rdi
  44b32d:	e8 8e c4 fb ff       	call   4077c0 <__cxa_call_terminate@plt>

Disassembly of section .fini:

build/src/xmvb-cpp.exe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000044b98c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold>:
  44b98c:	bf 68 07 93 00       	mov    $0x930768,%edi
  44b991:	e8 fa bd fb ff       	call   407790 <_ZSt20__throw_length_errorPKc@plt>
  44b996:	e8 73 d0 fb ff       	call   408a0e <_ZN5Eigen8internal19throw_std_bad_allocEv>
  44b99b:	48 89 c3             	mov    %rax,%rbx
  44b99e:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
  44b9a5:	e8 d6 37 08 00       	call   4cf180 <_ZN4xmvb9profiling11ScopedPhase4stopEv>
  44b9aa:	48 89 df             	mov    %rbx,%rdi
  44b9ad:	e8 7e be fb ff       	call   407830 <_Unwind_Resume@plt>
  44b9b2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
  44b9b9:	48 89 c3             	mov    %rax,%rbx
  44b9bc:	e8 6f 50 4b 00       	call   900a30 <_ZN4xmvb5mcscf15SpinConnectionsD1Ev>
  44b9c1:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
  44b9c8:	48 85 ff             	test   %rdi,%rdi
  44b9cb:	0f 84 a7 00 00 00    	je     44ba78 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xec>
  44b9d1:	4c 8b 27             	mov    (%rdi),%r12
  44b9d4:	be 18 00 00 00       	mov    $0x18,%esi
  44b9d9:	e8 82 b7 fb ff       	call   407160 <_ZdlPvm@plt>
  44b9de:	4c 89 e7             	mov    %r12,%rdi
  44b9e1:	eb e5                	jmp    44b9c8 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x3c>
  44b9e3:	e8 26 d0 fb ff       	call   408a0e <_ZN5Eigen8internal19throw_std_bad_allocEv>
  44b9e8:	be 18 00 00 00       	mov    $0x18,%esi
  44b9ed:	4c 89 ef             	mov    %r13,%rdi
  44b9f0:	e8 6b b7 fb ff       	call   407160 <_ZdlPvm@plt>
  44b9f5:	bf 10 00 00 00       	mov    $0x10,%edi
  44b9fa:	e8 e1 ba fb ff       	call   4074e0 <__cxa_allocate_exception@plt>
  44b9ff:	be d0 1e 95 00       	mov    $0x951ed0,%esi
  44ba04:	48 89 c7             	mov    %rax,%rdi
  44ba07:	49 89 c4             	mov    %rax,%r12
  44ba0a:	e8 61 b8 fb ff       	call   407270 <_ZNSt16invalid_argumentC1EPKc@plt>
  44ba0f:	ba 10 74 40 00       	mov    $0x407410,%edx
  44ba14:	be 00 5a 9a 00       	mov    $0x9a5a00,%esi
  44ba19:	4c 89 e7             	mov    %r12,%rdi
  44ba1c:	e8 cf bd fb ff       	call   4077f0 <__cxa_throw@plt>
  44ba21:	be 18 00 00 00       	mov    $0x18,%esi
  44ba26:	4c 89 ef             	mov    %r13,%rdi
  44ba29:	4c 89 bd 78 ff ff ff 	mov    %r15,-0x88(%rbp)
  44ba30:	e8 2b b7 fb ff       	call   407160 <_ZdlPvm@plt>
  44ba35:	eb 8a                	jmp    44b9c1 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x35>
  44ba37:	48 89 c3             	mov    %rax,%rbx
  44ba3a:	eb 85                	jmp    44b9c1 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x35>
  44ba3c:	4c 89 e7             	mov    %r12,%rdi
  44ba3f:	48 89 c3             	mov    %rax,%rbx
  44ba42:	e8 19 c1 fb ff       	call   407b60 <__cxa_free_exception@plt>
  44ba47:	e9 75 ff ff ff       	jmp    44b9c1 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x35>
  44ba4c:	bf 10 00 00 00       	mov    $0x10,%edi
  44ba51:	e8 8a ba fb ff       	call   4074e0 <__cxa_allocate_exception@plt>
  44ba56:	be a0 1e 95 00       	mov    $0x951ea0,%esi
  44ba5b:	48 89 c7             	mov    %rax,%rdi
  44ba5e:	49 89 c4             	mov    %rax,%r12
  44ba61:	e8 0a b8 fb ff       	call   407270 <_ZNSt16invalid_argumentC1EPKc@plt>
  44ba66:	ba 10 74 40 00       	mov    $0x407410,%edx
  44ba6b:	be 00 5a 9a 00       	mov    $0x9a5a00,%esi
  44ba70:	4c 89 e7             	mov    %r12,%rdi
  44ba73:	e8 78 bd fb ff       	call   4077f0 <__cxa_throw@plt>
  44ba78:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
  44ba7f:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  44ba86:	31 f6                	xor    %esi,%esi
  44ba88:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
  44ba8f:	00 
  44ba90:	e8 0b b9 fb ff       	call   4073a0 <memset@plt>
  44ba95:	31 c0                	xor    %eax,%eax
  44ba97:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  44ba9e:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  44baa5:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
  44baac:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
  44bab3:	48 8d 45 80          	lea    -0x80(%rbp),%rax
  44bab7:	48 39 c7             	cmp    %rax,%rdi
  44baba:	74 09                	je     44bac5 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x139>
  44babc:	48 c1 e6 03          	shl    $0x3,%rsi
  44bac0:	e8 9b b6 fb ff       	call   407160 <_ZdlPvm@plt>
  44bac5:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
  44bacc:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
  44bad3:	48 29 fe             	sub    %rdi,%rsi
  44bad6:	48 85 ff             	test   %rdi,%rdi
  44bad9:	0f 84 bf fe ff ff    	je     44b99e <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x12>
  44badf:	e8 7c b6 fb ff       	call   407160 <_ZdlPvm@plt>
  44bae4:	e9 b5 fe ff ff       	jmp    44b99e <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x12>
  44bae9:	e9 4e ff ff ff       	jmp    44ba3c <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0xb0>
  44baee:	31 d2                	xor    %edx,%edx
  44baf0:	48 89 95 78 ff ff ff 	mov    %rdx,-0x88(%rbp)
  44baf7:	e9 c5 fe ff ff       	jmp    44b9c1 <_ZNK4xmvb5mcscf19DirectCiSigmaAction22build_spin_connectionsERKSt6vectorIS2_IiSaIiEESaIS4_EE.cold+0x35>

Disassembly of section .fini:
