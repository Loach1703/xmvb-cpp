# Shared response/state channel scatter

Status: investigated in job 1264619, not retained in production. The identity
is exact, but the native end-to-end run did not beat the saved baseline.

At one fixed orbital point the response and accepted carriers use the same
spin-string links, generated target support, beta halo and channel ordering.
For a generated target $r$ and packed one-body channel $P$,

$$
A_{rP}=\sum_{\nu\in\mathcal N(r,P)}s_\nu\,\dot Y_{j_\nu},\qquad
B_{rP}=\sum_{\nu\in\mathcal N(r,P)}s_\nu\,Y_{j_\nu}.
$$

Only the two numerical input values differ. The neighborhood, channel,
fermionic sign and halo address $j_\nu$ are identical. Traverse each connection
once, compute its address once, and accumulate both numerical values. This is
an exact two-right-hand-side sparse operator application, not a replacement
of the structure response, a change of its accuracy, or an approximation to
either carrier.

The integral cotangent remains $A^T W B$, with the same exchange-orbit weight
matrix $W$. Sigma remains $E^T K A$, and the orbital directional sigma remains
$E^T(KA+\dot K B)$. Weights are still removed from $B$ before the latter
directional multiplication. Identical bra/ket requests scatter once and keep
their existing channel copy; distinct requests share the connection traversal.

## Existing budget, revised lifetime

Let $H$ be one halo panel size and $C$ one channel slab size, including block
width. The existing conservative planner already bounds ordinary requests by
$2H+2C$ and directional requests by $2H+3C$. It previously used only one halo,
overwriting the response halo after its scatter to read the accepted state.
Use both already-budgeted halos for a distinct response/state pair, read them
serially through the existing callbacks, then scatter them in one worker pass.
The tile geometry, 64 MiB cap and allocation capacity do not increase. No
per-worker coefficient or integral copies are introduced. Requests without a
distinct state still use one halo.

Callbacks complete before the scatter and retain no input views. Thus their
LRU mutations cannot invalidate numerical values in either shared halo. After
the scatter, both halos are dead; the same channel-slab reuse and end-of-Gram
barrier protect subsequent GEMMs. There is no persistent product-neighborhood
table: only the existing one-spin links and bounded target/halo metadata remain.

If a sorted distinct alpha halo has all $U_\alpha$ entries, its row map is the
identity. Both scatter and transpose gather can use the string index directly.
This is a cardinality identity, not a density cutoff or a full-space admission
decision. Partial halos continue to use their exact row maps.

The change removes repeated index/link traversal and one intervening read
synchronization. The two numerical scatters and all Hamiltonian/adjoint
arithmetic remain; no asymptotic electronic scaling reduction is asserted.
