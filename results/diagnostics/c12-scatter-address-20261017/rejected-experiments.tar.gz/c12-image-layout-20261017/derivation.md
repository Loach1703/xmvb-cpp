# Channel images in the transpose-gather layout

Status: investigated in jobs 1264632 and 1264635, not retained in production.
The layout and contiguous-weight implementations passed correctness tests
but did not improve native end-to-end performance versus the saved baseline.

The generated channel input is row-major: all packed one-body channels of
one target node are contiguous. This matches its scatter and the Gram
cotangent. The Hamiltonian image channel is a different object,

$$
Z=A K^T,\qquad \dot Z=B\dot K^T.
$$

Its beta transpose gather fixes a channel and walks target nodes. Keeping
$Z$ row-major imposes a stride equal to the number of channels at every
target lookup. Generate $Z$ directly into a column-major view of its existing
slab instead. Its beta gather then reads $Z_{tP}$ at `P*channel_rows+t`,
contiguous whenever target indices are consecutive, without a transposed
matrix or another complete image.

The alpha gather changes only its address formula. It sums the same signed
channel contributions in the same mathematical order. Arbitrary selected
support and exchange projection remain unchanged; no closure is assumed.

## Buffer lifetimes

1. A and B remain row-major throughout scatter and the integral Gram.
2. After the Gram barrier, B's former slab may be viewed column-major for
   ordinary Hamiltonian images. Nothing reads its former channel contents.
3. A directional action has a separate Z slab. Once all workers have consumed
   A for A K^T, synchronize before reinterpreting A's slab column-major for
   B dot(K)^T. Without this barrier, a column-major write by one worker could
   overwrite another worker's still-live row-major A range.
4. Add the two column-major images, apply the same exchange multiplicities,
   and consume both image writers before the next tile.

Only view types and addressing change. The GEMM writes the desired layout
directly. Numerical storage, tile geometry, all integral contractions, and
response accuracy are unchanged. Whether improved beta locality outweighs
alpha-gather and GEMM costs is an empirical end-to-end question.
