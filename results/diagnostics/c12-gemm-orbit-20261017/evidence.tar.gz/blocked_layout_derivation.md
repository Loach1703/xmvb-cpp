# Blocked channel output without another numerical slab

**Status:** exact but rejected experiment. Job 1264919 passed the existing
numerical checks but increased end-to-end and output time. Its production
implementation and header were deleted; reproducibility snapshots are archived
under `results/diagnostics/c12-gemm-orbit-20261017/`. This is not the default
layout or an established performance improvement.

Let a generated tile contain $N$ channel rows and $P$ packed orbital-pair
channels. Inputs $A,B\in\mathbb R^{N\times P}$ remain row-major while their
Gram contractions are formed. Only the disposable Hamiltonian images change
storage order.

For an output block with rows $r=\ell,\ldots,\ell+m-1$, encode its element
$(r,p)$ at

$$
o(r,p)=\ell P+pm+(r-\ell),\qquad 0\leq p<P.
$$

The block occupies exactly the same $mP$ scalar slots as before. This is a
bijection: it changes storage, not the channel operator or its support. A row's
two integer metadata entries are $\ell P+r-\ell$ and $m$. The consumer obtains
an element by adding the channel index times the second entry to the first.
No division, support traversal or full transpose is required at a lookup.

## Producers and lifetimes

- An out-of-place product writes column-major directly within its existing
  thread-owned row range. The GEMM count and source row range do not change.
- An in-place product already computes into a borrowed small scratch block
  and copies it back. That same copy-back writes the column-major encoding.
  Later source blocks occupy disjoint slots, so no unconsumed input is lost.
- All Hamiltonian/forcing images of a batch share this encoding. Their
  elementwise addition can use the same flat scalar ranges.
- The forward channel scatter writes its entire row-major destination before
  the next temporal request. The common accepted $B$ stays row-major until the
  final directional request consumes it, as required by the existing lifetime
  rule. Grams are formed before any destructive output permutation.

If $\Pi$ denotes this storage permutation, a consumer reads
$\Pi^{-1}\Pi W=W$. In particular the complete contraction remains

$$
E^T\Pi^{-1}(\Pi W)=E^TW.
$$

The selected-structure projection outside this kernel is unchanged. No CAS
completeness or selected-space closure is assumed. Alpha and beta consumers
both use the same accessor, including unequal-spin sectors and compact output.

## Exchange multiplicities

The output multiplicity is two except on fixed exchange orbits $a=b$. Put
the common factor two into GEMM's scalar coefficient, then halve just those
diagonal logical rows through the encoded strided row view. Both base and
direction products receive the same factor, so addition is unchanged. This
avoids a large strided weighting pass in the new layout. The integral-adjoint
Gram continues using its independently certified exact diagonal correction.

## Space and required validation

Only two integer entries per planned channel row are new. Capacity is capped
by the tile row limit (and the actual finite product count), not allocated for
an unbounded complete product space. Charge its entire capacity to the existing
workspace planner. Numerical slab count, workspace budget and worker ownership
remain unchanged; metadata are shared, not per-thread numerical replicas.

This is a data-layout experiment, not a lower asymptotic contraction order.
It requires independent action/adjoint/finite-difference checks and a matched
C12 end-to-end measurement before retention. Fewer cache-unfriendly strides
alone do not establish a speedup, and no DRAM traffic is inferred from layout.
