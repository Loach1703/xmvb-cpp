#pragma once

#include <algorithm>
#include <cstddef>

#include <Eigen/Core>

namespace xmvb::mcscf {

/** @brief Shared addresses for column-major blocks in one channel output slab.
 * Inputs remain row-major. A logical row has an offset and channel stride;
 * disjoint producer row ranges initialize their own metadata once per batch.
 */
class ChannelOutput {
public:
  explicit ChannelOutput(int capacity): rows_(2,capacity) {}

  std::size_t bytes() const noexcept { return sizeof(int)*rows_.size(); }

  void set_partition(int first,int last,int extent,int channels) {
    for (int begin=first;begin<last;) {
      const int count=std::min(extent,last-begin);
      for (int r=0;r<count;++r) {
        rows_(0,begin+r)=begin*channels+r;
        rows_(1,begin+r)=count;
      }
      begin+=count;
    }
  }

  double value(const double* data,int row,int channel) const noexcept {
    return data[rows_(0,row)+static_cast<std::size_t>(channel)*rows_(1,row)];
  }

  auto row(double* data,int row,int channels) const {
    return Eigen::Map<Eigen::VectorXd,0,Eigen::InnerStride<>>(
        data+rows_(0,row),channels,Eigen::InnerStride<>(rows_(1,row)));
  }

private:
  Eigen::Matrix<int,2,Eigen::Dynamic> rows_;
};

} // namespace xmvb::mcscf
