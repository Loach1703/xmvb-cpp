# Source-row layout for selected-structure backprojection

Status: tested prototype, not retained. Job1264792 on Hanhai22 converged in
four steps and36HVPs to-399.106646267330Eh. Native application time was
23.404603s versus the saved24.205419s baseline, but the separate instrumented
application was24.631926s versus24.682620s and projection time increased from
1.828959479s to2.484453354s. Peak native RSS increased from2650.95MiB to
2702.48MiB. These observations do not justify the extra packing and storage.
The production implementation was removed; its source and raw evidence are
retained only as an experiment record under results/diagnostics.

## Exact read support

For a completed output beta panel $J$, let $V=T_\alpha^T Y_J$ be its alpha
adjoint image. An original touched spin product $g=(a_g,b_g)$ consumes only

$$
v_g=\sum_{j\in J}V_{a_g j}(T_\beta)_{jb_g}.
$$

The original spin-product/structure incidence then adds $v_g$ to the selected
structures. The derivative of a left exterior projection requires

$$
\dot v_g=\sum_{j\in J}
\left[\dot V_{a_gj}(T_\beta)_{jb_g}
      +V_{a_gj}(\dot T_\beta)_{jb_g}\right].
$$

Define $A_0=\{a_g:g\text{ belongs to the original touched support}\}$ and a
compact index $\pi:A_0\rightarrow\{0,\ldots,|A_0|-1\}$. After completing the
alpha adjoint, pack

$$
P_{\pi(a),j}=V_{aj},\qquad
\dot P_{\pi(a),j}=\dot V_{aj},\qquad a\in A_0.
$$

Store the packed panels row-major. The two vector operands in each dot are
then contiguous: a row of $P$ and a column of the existing column-major beta
row block. Only rows that an actual original source group reads are packed;
the potentially larger generated halo is not copied into this layout.

This restriction is a read-support identity, not an invariant-subspace or CAS
closure assumption. It is valid for any selected structures and unequal spin
spaces. It must **not** be used to discard intermediate alpha transform paths:
the existing full/supported ordered adjoint completes first. Certified spin
exchange reconstruction and every directional term are unchanged.

## Bounded data ownership

The transformed column-major panels and their row-major source views are
shared workspace, reused by successive projection consumers. No worker owns a
copy. A non-owning Eigen reference also accepts full-row Hamiltonian blocks
without first converting each block into a temporary owning matrix.

Packing costs $O(|A_0||J|)$, with $|A_0|$ no larger than the number of original
source groups. Its work is not an asymptotic-order reduction; the benefit, if
any, comes from contiguous pointwise products and reuse when several source
groups share an alpha row. Neither a sparse representation nor SIMD alone
guarantees a total-time gain.

The common panel geometry charges a worst case of
$8|J|U_\alpha+2|J|U_\beta$ doubles: up to four output components, two
column work panels, two packed source panels and two beta row panels. Both
accepted and directional consumers use this geometry so an incidental width
change does not defeat accepted-point reuse. The existing per-caller budget
is unchanged; the packed panels never span all beta columns beyond its tile.
The broad resident-projection representation does not construct the packed
source panels at all.

The implementation must be qualified on arbitrary selected supports, both
exchange parities, unequal spins, resident/nonresident accepted images and
directional projections, followed by native C12 convergence. A memory-layout
argument alone is not an end-to-end speedup measurement.
