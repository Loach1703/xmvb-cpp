# Exact support restriction of an exterior projection jet

Status: validated prototype, not retained. Job1264796 passed the focused
support tests and9/9 regression targets, but gave no material native or
directional-transform improvement. Its production API and branch were removed.

Define $F_R x=T_\alpha(R)\operatorname{mat}(\mathcal E x)T_\beta(R)^T$,
where $x$ contains selected structure coefficients and $\mathcal E$ is their
sparse expansion into original touched spin products. For any emitted image
$Z$, a selected output requires $F_R^T Z$ and its directional derivative.
The selected structure subspace need not be closed under $T_\sigma$.

## Symbolic support, not numerical screening

Each exterior transform is an ordered product of diagonal scales and shears.
For one shear $L_e=I+c_e E_e$, its jet acts as

$$
v'_t=v_t+c_e s_e v_s,\qquad
\dot v'_t=\dot v_t+s_e(\dot c_e v_s+c_e\dot v_s),
$$

where $s_e=\pm1$ is the spin-string replacement sign. The derivative has
exactly the same possible graph edge as the primal shear. In particular,
$c_e=0$ does **not** permit removing the edge when $\dot c_e\ne0$.

An upper-triangular orbital matrix and its upper-triangular direction have
the same occupation-prefix reachability graph. For beta output column $b$,
let $\Omega_b$ be the exact depth-zero product support generated from the
original touched products, independently of amplitudes. The existing primal
adjoint restricts its alpha shear endpoints to $\Omega_b$. All contributing
ordered paths from an original product to an emitted column lie inside this
support. Differentiating such a path changes one edge weight, not its endpoints
or ordering. Consequently the same restriction is exact for the derivative.

The retained jet still evaluates both pieces

$$
\dot V=\dot T_\alpha^T Z+T_\alpha^T\dot Z,
$$

and the final beta contraction retains

$$
\dot v_{ab}=\sum_{j\in J}
\left[\dot V_{aj}(T_\beta)_{jb}
      +V_{aj}(\dot T_\beta)_{jb}\right].
$$

No overlap-multiplier, nonzero CI-residual or physical orbital/structure
response term is discarded. This is not a small-residual approximation.

## Implementation boundary and qualification

The ordinary and directional transforms share CSR support validation. The
existing directional ordered-shear kernel accepts this borrowed support;
its unrestricted callers retain their full transform. Output columns are
independent, with a single-spin membership mask per active worker/column.
There is no thread-local product array, dense exterior matrix or additional
accepted-point carrier. Formal full-space worst-case order is unchanged;
only paths excluded by exact selected support can be removed.

Qualification must compare the complete selected projection after both spin
transforms, not arbitrary discarded intermediate rows. Tests include nonclosed
three-seed support, unequal spins, two RHSs, nonzero input tangents, and a
diagonal primal transform with nonzero off-diagonal direction. Native C12
convergence and separate phase timing determine whether this implementation
is worth retaining; the graph identity alone does not imply a speedup.
