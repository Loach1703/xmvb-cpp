# Consume the combined directional channel image

Status: numerically correct prototype, not retained. Hanhai22 job1264789
converged in four steps and36HVPs, but native application time24.503898s did
not improve on the saved24.205419s predecessor. The coupled-image scope was
7.9791s versus7.9900s, essentially unchanged. The candidate production code
was removed; the independent no-forcing temporal regression test remains.

At the last orbital request of an ordered CI/orbital sweep, the independent
integral Grams have already consumed the accepted channels. The required
directional image is

$$
C=A K^T+B\dot K^T.
$$

$A$ contains the response channels, $B$ the unweighted accepted channels,
$K$ the accepted Hamiltonian channel kernel and $\dot K$ its integral
direction. Both products remain physical and necessary. In the usual caller,
only their sum is consumed; the second product has no independent writer.
Materializing that second product back into $B$, and then adding it to a
separately written $A K^T$, is unnecessary.

For each worker-owned row block use its existing dead-halo scratch $Q$:

$$
Q\leftarrow A_I K^T,\qquad
Q\leftarrow Q+B_I\dot K^T,\qquad
A_I\leftarrow Q.
$$

The result is copied back once. There is no accepted-slab product copyback
or later $A\mathrel{+}=B$ traversal. This is valid only after the Grams and
only for the final integral direction, as guaranteed by the temporal sweep.
Exact exchange weights are undone on $B$ before these image products;
reconstruction weights on the combined output are unchanged.

If a caller requests the forcing $B\dot K^T$ independently, it remains a
separate output and its established two-slab schedule is used. An adjoint-only
request omits both unused image products; a forcing-only request omits the
accepted-Hamiltonian product. These are actual output dependencies, not
small-residual or molecule-specific thresholds. The ordinary non-temporal
directional GEMM is unchanged.

The algorithm uses the same scratch partitions, barriers and64MiB workspace.
It reduces memory traversals, not the formal arithmetic order of the two
necessary Hamiltonian products. It requires independent no-forcing temporal
tests and a converged native C12 test before any speedup can be claimed.
