#include "linalg/inplace_product.hpp"

#include <cmath>
#include <stdexcept>

int main() {
  using xmvb::linalg::RowMatrix;
  for (int rows:{0,1,3,19,43}) for (int cols:{1,7,18})
    for (int capacity:{1,2,rows+3}) {
      RowMatrix storage=RowMatrix::Constant(rows+2,cols+3,-97.0);
      RowMatrix work=RowMatrix::Constant(capacity+2,cols+4,-43.0);
      Eigen::MatrixXd kernel(cols,cols);
      auto values=storage.block(1,1,rows,cols);
      for (int r=0;r<rows;++r) for (int c=0;c<cols;++c)
        values(r,c)=std::sin(0.13*(r+1)*(c+2));
      for (int r=0;r<cols;++r) for (int c=0;c<cols;++c)
        kernel(r,c)=std::cos(0.21*(r+2)*(c+1));
      const RowMatrix expected=values*kernel.transpose();
      xmvb::linalg::right_transpose_in_place(values,kernel,work.block(1,2,capacity,cols));
      if ((values-expected).norm()>2e-13*std::max(1.0,expected.norm()))
        throw std::runtime_error("borrowed in-place row product differs from full GEMM");
      for (int r=0;r<storage.rows();++r) for (int c=0;c<storage.cols();++c)
        if ((r==0 || r==rows+1 || c==0 || c>cols) && storage(r,c)!=-97.0)
          throw std::runtime_error("row product overwrote an unowned output element");
      for (int r=0;r<work.rows();++r) for (int c=0;c<work.cols();++c)
        if ((r==0 || r==capacity+1 || c<2 || c>=cols+2) && work(r,c)!=-43.0)
          throw std::runtime_error("row product exceeded its borrowed scratch extent");
      const RowMatrix source=values;
      const RowMatrix original_source=source;
      const Eigen::MatrixXd direction=0.3*kernel.transpose();
      const RowMatrix sum=values*kernel.transpose()+source*direction.transpose();
      xmvb::linalg::right_transpose_sum_in_place(values,kernel,source,direction,
          work.block(1,2,capacity,cols));
      if ((values-sum).norm()>2e-13*std::max(1.0,sum.norm()))
        throw std::runtime_error("borrowed sum product differs from independent GEMMs");
      if (source!=original_source)
        throw std::runtime_error("sum product modified its read-only source");
      for (int r=0;r<storage.rows();++r) for (int c=0;c<storage.cols();++c)
        if ((r==0 || r==rows+1 || c==0 || c>cols) && storage(r,c)!=-97.0)
          throw std::runtime_error("sum product overwrote an unowned output element");
      for (int r=0;r<work.rows();++r) for (int c=0;c<work.cols();++c)
        if ((r==0 || r==capacity+1 || c<2 || c>=cols+2) && work(r,c)!=-43.0)
          throw std::runtime_error("sum product exceeded its borrowed scratch extent");
    }
}
