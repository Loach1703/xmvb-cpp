#pragma once

#include <algorithm>
#include <cstddef>
#include <stdexcept>

#include <Eigen/Cholesky>
#include <Eigen/Core>

namespace xmvb::linalg {

/** @brief Restrict an SPD inverse to ker(A^T), using precomputed images.
 * inverse contains [R r, R A], where R is the ambient inverse and A contains
 * independent constraint covectors. Returns R r-R A(A^T R A)^-1 A^T R r.
 * Only the constraint-sized Gram is factored; no physical action is evaluated.
 */
inline Eigen::VectorXd constrained_inverse(
    const Eigen::Ref<const Eigen::MatrixXd>& inverse,
    const Eigen::Ref<const Eigen::MatrixXd>& constraints) {
  if (inverse.rows() != constraints.rows() ||
      inverse.cols() != constraints.cols() + 1)
    throw std::invalid_argument("constrained inverse image dimensions disagree");
  if (constraints.cols() == 0) return inverse.col(0);
  const auto inverse_constraints = inverse.rightCols(constraints.cols());
  const Eigen::MatrixXd gram = constraints.transpose() * inverse_constraints;
  const Eigen::LLT<Eigen::MatrixXd> factor(gram);
  if (factor.info() != Eigen::Success)
    throw std::runtime_error("constrained inverse model is not positive definite");
  return inverse.col(0) - inverse_constraints *
      factor.solve(constraints.transpose() * inverse.col(0));
}

/** @brief Same constrained inverse, streaming R A rather than storing it.
 * The constraint columns may borrow a Krylov metric basis. Form the small
 * Gram in bounded column panels, then apply R to the corrected RHS. Scratch
 * is O(workspace_bytes+n), plus the constraint-sized Gram, never n by rank.
 */
template<class Inverse>
Eigen::VectorXd constrained_inverse(
    const Eigen::Ref<const Eigen::VectorXd>& rhs,
    const Eigen::Ref<const Eigen::MatrixXd>& constraints,
    const Inverse& inverse, std::size_t workspace_bytes) {
  if (rhs.size() != constraints.rows() || workspace_bytes == 0)
    throw std::invalid_argument("streamed constrained inverse dimensions disagree");
  const Eigen::VectorXd unconstrained = inverse(rhs).col(0);
  const Eigen::Index rank = constraints.cols();
  if (rank == 0) return unconstrained;
  // Allow input scaling, output and the block-local triangular workspace.
  const std::size_t column_bytes = 3 * sizeof(double) * std::max<Eigen::Index>(1, rhs.size());
  const Eigen::Index width = std::min<std::size_t>(rank,
      std::max<std::size_t>(1, workspace_bytes / column_bytes));
  Eigen::MatrixXd gram(rank, rank);
  for (Eigen::Index first = 0; first < rank; first += width) {
    const Eigen::Index count = std::min(width, rank - first);
    const Eigen::MatrixXd images = inverse(constraints.middleCols(first, count));
    gram.middleCols(first, count).noalias() = constraints.transpose() * images;
  }
  const Eigen::LLT<Eigen::MatrixXd> factor(gram);
  if (factor.info() != Eigen::Success)
    throw std::runtime_error("streamed constrained inverse model is not positive definite");
  const Eigen::VectorXd corrected = rhs - constraints *
      factor.solve(constraints.transpose() * unconstrained);
  return inverse(corrected).col(0);
}

}  // namespace xmvb::linalg
